#!/bin/bash

./emsdk construct_env
source ./emsdk_set_env.sh

