# Wagyu Port - Netflix's WebGPU bindings for Emscripten

Wagyu is Netflix's implementation of WebGPU bindings for Emscripten.

This package provides the legacy (old) webgpu.h header used by Emscripten, and
a copy of the current standard (new) webgpu.h provided by webgp-native:
https://github.com/webgpu-native/webgpu-headers/

There is also a webgpu_compat.h header that provides some convenience macros
to facilitate switching between these "old" and "new" wagyu-port versions.

This package optionally provides Netflix extensions to the WebGPU API, which
are available from the webgpu_wagyu.h header. These extensions are not part of
the WebGPU standard, and are specific to Netflix's use cases.

## Usage

The recommended way to use this is with a remote port file, which can be
downloaded from the wagyu-port repository:
https://github.netflix.net/corp/nrdp-wagyu-port/

To use the remote port file, pass it as an option like this to your
emscripten build commands:
```
--use-port=[your_path]/wagyu-remoteport.py
```

You can also directly use the local port file `wagyu-port.py` from the
wagyu-port repository (or a copy of it).
```
--use-port=[your_path]/wagyu-port.py
```

## Configuration

You can configure the port by passing options to `--use-port` as key=value
pairs delimited by colons.

For example:
```
--use-port=wagyu-remoteport.py:extensions=true:stubs=true
```

Supported options:

  - extensions:

    Controls whether Netflix Wagyu extensions should be used.

    true to enable, false to disable (default is false).

  - stubs:

    Controls whether the stub JavaScript implementations of the WebGPU
    functions, or to use the full JavaScript implementation.

    true to enable, false to disable (default is true).

    For the "old" wagyu-port, if you set USE_WEBGPU=1 then stubs will
    be disabled. For the "new" wagyu-port, disabling stubs is not currently
    supported.

(c) 2025 Netflix, Inc. Do not copy or use without prior written permission from Netflix, Inc.
