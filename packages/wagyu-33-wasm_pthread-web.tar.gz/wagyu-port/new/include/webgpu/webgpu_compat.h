#ifndef WEBGPU_COMPAT_H
#define WEBGPU_COMPAT_H

#if defined(__cplusplus)
#define WGPU_STRING_VIEW(s)            \
    WGPUStringView                     \
    {                                  \
        s, (s != NULL) ? strlen(s) : 0 \
    }
#else
#define WGPU_STRING_VIEW(s)            \
    (WGPUStringView)                   \
    {                                  \
        s, (s != NULL) ? strlen(s) : 0 \
    }
#endif

#define WGPU_STRING_VIEW_TO_STRING(s) std::string((s.data != NULL) ? s.data : "", (s.data != NULL) ? s.length : 0)
#define WGPU_STRING_VIEW_TO_CSTR(s) WGPU_STRING_VIEW_TO_STRING(s).c_str()

#if defined(__cplusplus)
#define WGPU_STRING_VIEW_FROM_STRING(s) \
    WGPUStringView                      \
    {                                   \
        strdup(s.c_str()), s.length()   \
    }
#else
#define WGPU_STRING_VIEW_FROM_STRING(s) \
    (WGPUStringView)                    \
    {                                   \
        strdup(s.c_str()), s.length()   \
    }
#endif

#define WGPU_STRING_VIEW_FREE(s) \
    free(const_cast<char *>(s.data))

#define WGPU_ADDREF(d, o) wgpu##d##AddRef(o)

#define WGPU_CHECK_STATUS(s)             \
    do {                                 \
        WGPUStatus status = s;           \
        assert(s == WGPUStatus_Success); \
        static_cast<void>(status);       \
    } while (0)

#define WGPUComputePassTimestampWrites WGPUPassTimestampWrites
#define WGPURenderPassTimestampWrites WGPUPassTimestampWrites

// FIX - we really shouldn't do this
#define WGPUFeatureName_Undefined static_cast<WGPUFeatureName>(0x00000000)

#if defined(__cplusplus)
#define WGPU_WAGYU_STRING_VIEW(s)      \
    WGPUWagyuStringView                \
    {                                  \
        s, (s != NULL) ? strlen(s) : 0 \
    }
#else
#define WGPU_WAGYU_STRING_VIEW(s)      \
    (WGPUWagyuStringView)              \
    {                                  \
        s, (s != NULL) ? strlen(s) : 0 \
    }
#endif

#endif // WEBGPU_COMPAT_H
