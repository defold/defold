#
# Copyright (C) 2008 Google Inc.
#
# Licensed under the Apache License 2.0;

"""This package's modules adapt the gdata library to run in other environments

The first example is the appengine module which contains functions and
classes which modify a GDataService object to run on Google App Engine.
"""
