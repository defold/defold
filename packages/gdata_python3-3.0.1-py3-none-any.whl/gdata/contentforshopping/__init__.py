#
# Copyright (C) 2010-2011 Google Inc.
#
# Licensed under the Apache License 2.0;



"""Support for the Content API for Shopping

See: http://code.google.com/apis/shopping/content/index.html
"""
