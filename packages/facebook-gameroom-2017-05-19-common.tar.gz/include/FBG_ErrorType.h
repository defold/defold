#ifndef FBG_ERROR_TYPE_H
#define FBG_ERROR_TYPE_H

typedef enum _fbgErrorType {
  fbgError_Unknown,
  fbgError_Cancelled,
} fbgErrorType;

#endif
