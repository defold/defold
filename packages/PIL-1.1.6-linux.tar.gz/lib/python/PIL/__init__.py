#
# The Python Imaging Library.
# $Id: __init__.py 2134 2004-10-06 08:55:20Z fredrik $
#
# package placeholder
#
# Copyright (c) 1999 by Secret Labs AB.
#
# See the README file for information on usage and redistribution.
#

# ;-)
