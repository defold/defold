The following lines in cutils.py are removed from the original version (0.3.159.1)
#import Blender
#from Blender.Mathutils import *
