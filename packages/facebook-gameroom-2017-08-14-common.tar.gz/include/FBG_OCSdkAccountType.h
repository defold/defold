#ifndef FBG_OCSDKACOCUNTTYPE_H
#define FBG_OCSDKACOCUNTTYPE_H

#include "OVR_Platform_Defs.h"

typedef enum _OCSdkAccountType {
	unknown_account_type,
	oculus,
	gameroom,
} OCSdkAccountType;

#endif
