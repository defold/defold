#ifndef NV_CONFIG
#define NV_CONFIG

#define HAVE_UNISTD_H
#define HAVE_STDARG_H
#define HAVE_SIGNAL_H
#define HAVE_EXECINFO_H
/* #undef HAVE_MALLOC_H */

#define HAVE_PNG
/* #undef HAVE_JPEG */
/* #undef HAVE_TIFF */
/* #undef HAVE_OPENEXR */

/* #undef HAVE_MAYA */

#endif // NV_CONFIG
