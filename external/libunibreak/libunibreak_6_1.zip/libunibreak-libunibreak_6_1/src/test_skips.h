static const unsigned int testSkipsWord[] = {
    0
};

static const unsigned int testSkipsGrapheme[] = {
    0
};

static const unsigned int testSkipsLine[] = {
     1161,  /* Use LB25: no regex tailoring as in Example 7 */
     1163,  /* Use LB25: no regex tailoring as in Example 7 */
     1165,  /* Use LB25: no regex tailoring as in Example 7 */
     1167,  /* Use LB25: no regex tailoring as in Example 7 */
     2873,  /* Use LB25: no regex tailoring as in Example 7 */
     2875,  /* Use LB25: no regex tailoring as in Example 7 */
     4425,  /* Use LB25: no regex tailoring as in Example 7 */
     4427,  /* Use LB25: no regex tailoring as in Example 7 */
     4473,  /* Use LB25: no regex tailoring as in Example 7 */
     4475,  /* Use LB25: no regex tailoring as in Example 7 */
     4597,  /* Use LB25: no regex tailoring as in Example 7 */
     4599,  /* Use LB25: no regex tailoring as in Example 7 */
     4645,  /* Use LB25: no regex tailoring as in Example 7 */
     4647,  /* Use LB25: no regex tailoring as in Example 7 */
     5109,  /* Use LB25: no regex tailoring as in Example 7 */
     5111,  /* Use LB25: no regex tailoring as in Example 7 */
     6149,  /* Use LB25: no regex tailoring as in Example 7 */
     6151,  /* Use LB25: no regex tailoring as in Example 7 */
     6153,  /* Use LB25: no regex tailoring as in Example 7 */
     6155,  /* Use LB25: no regex tailoring as in Example 7 */
     7477,  /* Use LB25: no regex tailoring as in Example 7 */
     7486,  /* Use LB25: no regex tailoring as in Example 7 */
     7491,  /* Use LB25: no regex tailoring as in Example 7 */
     7576,  /* Use LB25: no regex tailoring as in Example 7 */
     7577,  /* Use LB25: no regex tailoring as in Example 7 */
     7578,  /* Use LB25: no regex tailoring as in Example 7 */
     7579,  /* Use LB25: no regex tailoring as in Example 7 */
     7580,  /* Use LB25: no regex tailoring as in Example 7 */
     7581,  /* Use LB25: no regex tailoring as in Example 7 */
     7583,  /* Use LB25: no regex tailoring as in Example 7 */
     7584,  /* Use LB25: no regex tailoring as in Example 7 */
     7585,  /* Use LB25: no regex tailoring as in Example 7 */
     7586,  /* Use LB25: no regex tailoring as in Example 7 */
     7587,  /* Use LB25: no regex tailoring as in Example 7 */
     7681,  /* Unknown (XX) is treated as AL in this implementation */
     0
};
