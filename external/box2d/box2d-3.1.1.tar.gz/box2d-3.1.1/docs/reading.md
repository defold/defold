# Further Reading
- [Erin Catto's Publications](https://box2d.org/publications/)
- [Erin Catto's Blog Posts](https://box2d.org/posts/)
- Collision Detection in Interactive 3D Environments, Gino van den Bergen, 2004
- Real-Time Collision Detection, Christer Ericson, 2005
