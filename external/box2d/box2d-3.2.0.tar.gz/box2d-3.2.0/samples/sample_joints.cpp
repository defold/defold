// SPDX-FileCopyrightText: 2022 Erin Catto
// SPDX-License-Identifier: MIT

#include "car.h"
#include "donut.h"
#include "doohickey.h"
#include "draw.h"
#include "human.h"
#include "sample.h"
#include "utils.h"

#include "box2d/box2d.h"
#include "box2d/math_functions.h"

#include <GLFW/glfw3.h>
#include <imgui.h>

// Test the distance joint and all options
class DistanceJoint : public Sample
{
public:
	enum
	{
		e_maxCount = 10
	};

	explicit DistanceJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 12.0f };
			m_context->camera.zoom = 25.0f * 0.35f;
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			m_groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		m_count = 0;
		m_hertz = 5.0f;
		m_dampingRatio = 0.5f;
		m_length = 1.0f;
		m_minLength = m_length;
		m_maxLength = m_length;
		m_tensionForce = 2000.0f;
		m_compressionForce = 100.0f;
		m_enableSpring = false;
		m_enableLimit = false;

		for ( int i = 0; i < e_maxCount; ++i )
		{
			m_bodyIds[i] = b2_nullBodyId;
			m_jointIds[i] = b2_nullJointId;
		}

		CreateScene( 1 );
	}

	void CreateScene( int newCount )
	{
		for ( int i = 0; i < m_count; ++i )
		{
			b2DestroyJoint( m_jointIds[i] );
			m_jointIds[i] = b2_nullJointId;
		}

		for ( int i = 0; i < m_count; ++i )
		{
			b2DestroyBody( m_bodyIds[i] );
			m_bodyIds[i] = b2_nullBodyId;
		}

		m_count = newCount;

		float radius = 0.25f;
		b2Circle circle = { { 0.0f, 0.0f }, radius };

		b2ShapeDef shapeDef = b2DefaultShapeDef();
		shapeDef.density = 20.0f;

		float yOffset = 20.0f;

		b2DistanceJointDef jointDef = b2DefaultDistanceJointDef();
		jointDef.hertz = m_hertz;
		jointDef.dampingRatio = m_dampingRatio;
		jointDef.length = m_length;
		jointDef.lowerSpringForce = -m_tensionForce;
		jointDef.upperSpringForce = m_compressionForce;
		jointDef.minLength = m_minLength;
		jointDef.maxLength = m_maxLength;
		jointDef.enableSpring = m_enableSpring;
		jointDef.enableLimit = m_enableLimit;

		b2BodyId prevBodyId = m_groundId;
		for ( int i = 0; i < m_count; ++i )
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.angularDamping = 1.0f;
			bodyDef.position = { m_length * ( i + 1.0f ), yOffset };
			m_bodyIds[i] = b2CreateBody( m_worldId, &bodyDef );
			b2CreateCircleShape( m_bodyIds[i], &shapeDef, &circle );

			b2Pos pivotA = { m_length * i, yOffset };
			b2Pos pivotB = { m_length * ( i + 1.0f ), yOffset };
			jointDef.base.bodyIdA = prevBodyId;
			jointDef.base.bodyIdB = m_bodyIds[i];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivotA );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivotB );
			m_jointIds[i] = b2CreateDistanceJoint( m_worldId, &jointDef );

			prevBodyId = m_bodyIds[i];
		}
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Length", &m_length, 0.1f, 4.0f, "%3.1f" ) )
		{
			for ( int i = 0; i < m_count; ++i )
			{
				b2DistanceJoint_SetRestLength( m_jointIds[i], m_length );
				b2Joint_WakeBodies( m_jointIds[i] );
			}
		}

		if ( ImGui::Checkbox( "Spring", &m_enableSpring ) )
		{
			for ( int i = 0; i < m_count; ++i )
			{
				b2DistanceJoint_EnableSpring( m_jointIds[i], m_enableSpring );
				b2Joint_WakeBodies( m_jointIds[i] );
			}
		}

		if ( m_enableSpring )
		{
			if ( ImGui::SliderFloat( "Tension", &m_tensionForce, 0.0f, 4000.0f ) )
			{
				for ( int i = 0; i < m_count; ++i )
				{
					b2DistanceJoint_SetSpringForceRange( m_jointIds[i], -m_tensionForce, m_compressionForce );
					b2Joint_WakeBodies( m_jointIds[i] );
				}
			}

			if ( ImGui::SliderFloat( "Compression", &m_compressionForce, 0.0f, 200.0f ) )
			{
				for ( int i = 0; i < m_count; ++i )
				{
					b2DistanceJoint_SetSpringForceRange( m_jointIds[i], -m_tensionForce, m_compressionForce );
					b2Joint_WakeBodies( m_jointIds[i] );
				}
			}

			if ( ImGui::SliderFloat( "Hertz", &m_hertz, 0.0f, 15.0f, "%3.1f" ) )
			{
				for ( int i = 0; i < m_count; ++i )
				{
					b2DistanceJoint_SetSpringHertz( m_jointIds[i], m_hertz );
					b2Joint_WakeBodies( m_jointIds[i] );
				}
			}

			if ( ImGui::SliderFloat( "Damping", &m_dampingRatio, 0.0f, 4.0f, "%3.1f" ) )
			{
				for ( int i = 0; i < m_count; ++i )
				{
					b2DistanceJoint_SetSpringDampingRatio( m_jointIds[i], m_dampingRatio );
					b2Joint_WakeBodies( m_jointIds[i] );
				}
			}
		}

		if ( ImGui::Checkbox( "Limit", &m_enableLimit ) )
		{
			for ( int i = 0; i < m_count; ++i )
			{
				b2DistanceJoint_EnableLimit( m_jointIds[i], m_enableLimit );
				b2Joint_WakeBodies( m_jointIds[i] );
			}
		}

		if ( m_enableLimit )
		{
			if ( ImGui::SliderFloat( "Min Length", &m_minLength, 0.1f, 4.0f, "%3.1f" ) )
			{
				for ( int i = 0; i < m_count; ++i )
				{
					b2DistanceJoint_SetLimits( m_jointIds[i], m_minLength, m_maxLength );
					b2Joint_WakeBodies( m_jointIds[i] );
				}
			}

			if ( ImGui::SliderFloat( "Max Length", &m_maxLength, 0.1f, 4.0f, "%3.1f" ) )
			{
				for ( int i = 0; i < m_count; ++i )
				{
					b2DistanceJoint_SetLimits( m_jointIds[i], m_minLength, m_maxLength );
					b2Joint_WakeBodies( m_jointIds[i] );
				}
			}
		}

		int count = m_count;
		if ( ImGui::SliderInt( "Count", &count, 1, e_maxCount ) )
		{
			CreateScene( count );
		}

		ImGui::PopItemWidth();

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new DistanceJoint( context );
	}

	b2BodyId m_groundId;
	b2BodyId m_bodyIds[e_maxCount];
	b2JointId m_jointIds[e_maxCount];
	int m_count;
	float m_hertz;
	float m_dampingRatio;
	float m_length;
	float m_tensionForce;
	float m_compressionForce;
	float m_minLength;
	float m_maxLength;
	bool m_enableSpring;
	bool m_enableLimit;
};

static int sampleDistanceJoint = RegisterSample( "Joints", "Distance Joint", DistanceJoint::Create );

/// This test shows how to use a motor joint. A motor joint
/// can be used to animate a dynamic body. With finite motor forces
/// the body can be blocked by collision with other bodies.
class MotorJoint : public Sample
{
public:
	explicit MotorJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 7.0f };
			m_context->camera.zoom = 25.0f * 0.4f;
		}

		b2BodyId groundId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		m_transform = { .p = { 0.0f, 8.0f }, .q = b2Rot_identity };

		// Define a target body
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_kinematicBody;
			bodyDef.position = m_transform.p;
			m_targetId = b2CreateBody( m_worldId, &bodyDef );
		}

		// Define motorized body
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = m_transform.p;
			m_bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon box = b2MakeBox( 2.0f, 0.5f );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyId, &shapeDef, &box );

			m_maxForce = 5000.0f;
			m_maxTorque = 500.0f;

			b2MotorJointDef jointDef = b2DefaultMotorJointDef();
			jointDef.base.bodyIdA = m_targetId;
			jointDef.base.bodyIdB = m_bodyId;
			jointDef.linearHertz = 4.0f;
			jointDef.linearDampingRatio = 0.7f;
			jointDef.angularHertz = 4.0f;
			jointDef.angularDampingRatio = 0.7f;
			jointDef.maxSpringForce = m_maxForce;
			jointDef.maxSpringTorque = m_maxTorque;

			m_jointId = b2CreateMotorJoint( m_worldId, &jointDef );
		}

		// Define spring body
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { -2.0f, 2.0f };
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon box = b2MakeSquare( 0.5f );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2MotorJointDef jointDef = b2DefaultMotorJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Add( b2ToVec2( bodyDef.position ), { 0.25f, 0.25f } );
			jointDef.base.localFrameB.p = { 0.25f, 0.25f };
			jointDef.linearHertz = 7.5f;
			jointDef.linearDampingRatio = 0.7f;
			jointDef.angularHertz = 7.5f;
			jointDef.angularDampingRatio = 0.7f;
			jointDef.maxSpringForce = 500.0f;
			jointDef.maxSpringTorque = 10.0f;

			b2CreateMotorJoint( m_worldId, &jointDef );
		}

		m_speed = 1.0f;
		m_time = 0.0f;
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Speed", &m_speed, -5.0f, 5.0f, "%.0f" ) )
		{
		}

		if ( ImGui::SliderFloat( "Max Force", &m_maxForce, 0.0f, 10000.0f, "%.0f" ) )
		{
			b2MotorJoint_SetMaxSpringForce( m_jointId, m_maxForce );
		}

		if ( ImGui::SliderFloat( "Max Torque", &m_maxTorque, 0.0f, 10000.0f, "%.0f" ) )
		{
			b2MotorJoint_SetMaxSpringTorque( m_jointId, m_maxTorque );
		}

		ImGui::PopItemWidth();

		if ( ImGui::Button( "Apply Impulse" ) )
		{
			b2Body_ApplyLinearImpulseToCenter( m_bodyId, { 100.0f, 0.0f }, true );
		}

		return true;
	}

	void Step() override
	{
		float timeStep = m_context->hertz > 0.0f ? 1.0f / m_context->hertz : 0.0f;

		if ( m_context->pause )
		{
			if ( m_context->singleStep == 0 )
			{
				timeStep = 0.0f;
			}
		}

		if ( timeStep > 0.0f )
		{
			m_time += m_speed * timeStep;

			b2Pos linearOffset;
			linearOffset.x = 6.0f * sinf( 2.0f * m_time );
			linearOffset.y = 8.0f + 4.0f * sinf( 1.0f * m_time );

			float angularOffset = 2.0f * m_time;
			m_transform = { linearOffset, b2MakeRot( angularOffset ) };

			bool wake = true;
			b2Body_SetTargetTransform( m_targetId, m_transform, timeStep, wake );
		}

		DrawTransform( m_draw, m_transform, 1.0f );

		Sample::Step();

		b2Vec2 force = b2Joint_GetConstraintForce( m_jointId );
		float torque = b2Joint_GetConstraintTorque( m_jointId );

		DrawScreenTextLine( "force = {%3.f, %3.f}, torque = %3.f", force.x, force.y, torque );
	}

	static Sample* Create( SampleContext* context )
	{
		return new MotorJoint( context );
	}

	b2BodyId m_targetId;
	b2BodyId m_bodyId;
	b2JointId m_jointId;
	b2WorldTransform m_transform;
	float m_time;
	float m_speed;
	float m_maxForce;
	float m_maxTorque;
};

static int sampleMotorJoint = RegisterSample( "Joints", "Motor Joint", MotorJoint::Create );

class TopDownFriction : public Sample
{
public:
	explicit TopDownFriction( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 10.0f };
			m_context->camera.zoom = 12.0f;
		}

		b2BodyId groundId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -10.0f, 0.0f }, { 10.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			segment = { { -10.0f, 0.0f }, { -10.0f, 20.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			segment = { { 10.0f, 0.0f }, { 10.0f, 20.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			segment = { { -10.0f, 20.0f }, { 10.0f, 20.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		b2MotorJointDef jointDef = b2DefaultMotorJointDef();
		jointDef.base.bodyIdA = groundId;
		jointDef.base.collideConnected = true;
		jointDef.maxVelocityForce = 10.0f;
		jointDef.maxVelocityTorque = 10.0f;

		b2Capsule capsule = { { -0.25f, 0.0f }, { 0.25f, 0.0f }, 0.25f };
		b2Circle circle = { { 0.0f, 0.0f }, 0.35f };
		b2Polygon square = b2MakeSquare( 0.35f );

		b2BodyDef bodyDef = b2DefaultBodyDef();
		bodyDef.type = b2_dynamicBody;
		bodyDef.gravityScale = 0.0f;
		b2ShapeDef shapeDef = b2DefaultShapeDef();
		shapeDef.material.restitution = 0.8f;

		int n = 10;
		float x = -5.0f, y = 15.0f;
		for ( int i = 0; i < n; ++i )
		{
			for ( int j = 0; j < n; ++j )
			{
				bodyDef.position = { x, y };
				b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

				int remainder = ( n * i + j ) % 4;
				if ( remainder == 0 )
				{
					b2CreateCapsuleShape( bodyId, &shapeDef, &capsule );
				}
				else if ( remainder == 1 )
				{
					b2CreateCircleShape( bodyId, &shapeDef, &circle );
				}
				else if ( remainder == 2 )
				{
					b2CreatePolygonShape( bodyId, &shapeDef, &square );
				}
				else
				{
					b2Polygon poly = RandomPolygon( 0.75f );
					poly.radius = 0.1f;
					b2CreatePolygonShape( bodyId, &shapeDef, &poly );
				}

				jointDef.base.bodyIdB = bodyId;
				b2CreateMotorJoint( m_worldId, &jointDef );

				x += 1.0f;
			}

			x = -5.0f;
			y -= 1.0f;
		}
	}

	bool DrawControls() override
	{
		if ( ImGui::Button( "Explode" ) )
		{
			b2ExplosionDef def = b2DefaultExplosionDef();
			def.position = { 0.0f, 10.0f };
			def.radius = 10.0f;
			def.falloff = 5.0f;
			def.impulsePerLength = 10.0f;
			b2World_Explode( m_worldId, &def );

			DrawCircle( m_draw, def.position, 10.0f, b2_colorWhite );
		}

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new TopDownFriction( context );
	}
};

static int sampleTopDownFriction = RegisterSample( "Joints", "Top Down Friction", TopDownFriction::Create );

// This sample shows how to use a filter joint to prevent collision between two bodies.
// This is more specific than shape filters. It also shows that sleeping is coupled by the filter joint.
class FilterJoint : public Sample
{
public:
	explicit FilterJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 7.0f };
			m_context->camera.zoom = 25.0f * 0.4f;
		}

		{
			b2BodyId groundId;
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { -4.0f, 2.0f };
			b2BodyId bodyId1 = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon box = b2MakeSquare( 2.0f );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( bodyId1, &shapeDef, &box );

			bodyDef.position = { 4.0f, 2.0f };
			b2BodyId bodyId2 = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId2, &shapeDef, &box );

			b2FilterJointDef jointDef = b2DefaultFilterJointDef();
			jointDef.base.bodyIdA = bodyId1;
			jointDef.base.bodyIdB = bodyId2;

			b2CreateFilterJoint( m_worldId, &jointDef );
		}
	}

	static Sample* Create( SampleContext* context )
	{
		return new FilterJoint( context );
	}
};

static int sampleFilterJoint = RegisterSample( "Joints", "Filter Joint", FilterJoint::Create );

class RevoluteJoint : public Sample
{
public:
	explicit RevoluteJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 15.5f };
			m_context->camera.zoom = 25.0f * 0.7f;
		}

		b2BodyId groundId = b2_nullBodyId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.position = { 0.0f, -1.0f };
			groundId = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon box = b2MakeBox( 40.0f, 1.0f );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( groundId, &shapeDef, &box );
		}

		m_enableSpring = false;
		m_enableLimit = false;
		m_enableMotor = false;
		m_hertz = 2.0f;
		m_dampingRatio = 0.5f;
		m_targetDegrees = 45.0f;
		m_motorSpeed = 1.0f;
		m_motorTorque = 1000.0f;

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { -10.0f, 20.0f };
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1.0f;

			b2Capsule capsule = { { 0.0f, -1.0f }, { 0.0f, 6.0f }, 0.5f };
			b2CreateCapsuleShape( bodyId, &shapeDef, &capsule );

			b2Pos pivot = { -10.0f, 20.5f };
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.q = b2MakeRot( 0.5f * B2_PI );
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.targetAngle = B2_PI * m_targetDegrees / 180.0f;
			jointDef.enableSpring = m_enableSpring;
			jointDef.hertz = m_hertz;
			jointDef.dampingRatio = m_dampingRatio;
			jointDef.motorSpeed = m_motorSpeed;
			jointDef.maxMotorTorque = m_motorTorque;
			jointDef.enableMotor = m_enableMotor;
			jointDef.lowerAngle = -0.5f * B2_PI;
			jointDef.upperAngle = 0.05f * B2_PI;
			jointDef.enableLimit = m_enableLimit;

			m_jointId1 = b2CreateRevoluteJoint( m_worldId, &jointDef );

			b2Joint_SetConstraintTuning( m_jointId1, 60.0f, 20.0f );
		}

		{
			b2Circle circle = {};
			circle.radius = 2.0f;

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { 5.0f, 30.0f };
			m_ball = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1.0f;

			b2CreateCircleShape( m_ball, &shapeDef, &circle );
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.position = { 20.0f, 10.0f };
			bodyDef.type = b2_dynamicBody;
			b2BodyId body = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon box = b2MakeOffsetBox( 10.0f, 0.5f, { -10.0f, 0.0f }, b2Rot_identity );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1.0f;
			b2CreatePolygonShape( body, &shapeDef, &box );

			b2Pos pivot = { 19.0f, 10.0f };
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = body;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.lowerAngle = -0.25f * B2_PI;
			jointDef.upperAngle = 0.0f * B2_PI;
			jointDef.enableLimit = true;
			jointDef.enableMotor = true;
			jointDef.motorSpeed = 0.0f;
			jointDef.maxMotorTorque = m_motorTorque;

			m_jointId2 = b2CreateRevoluteJoint( m_worldId, &jointDef );
		}
	}

	bool DrawControls() override
	{
		if ( ImGui::Checkbox( "Limit", &m_enableLimit ) )
		{
			b2RevoluteJoint_EnableLimit( m_jointId1, m_enableLimit );
			b2Joint_WakeBodies( m_jointId1 );
		}

		if ( ImGui::Checkbox( "Motor", &m_enableMotor ) )
		{
			b2RevoluteJoint_EnableMotor( m_jointId1, m_enableMotor );
			b2Joint_WakeBodies( m_jointId1 );
		}

		if ( m_enableMotor )
		{
			ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
			if ( ImGui::SliderFloat( "Max Torque", &m_motorTorque, 0.0f, 5000.0f, "%.0f" ) )
			{
				b2RevoluteJoint_SetMaxMotorTorque( m_jointId1, m_motorTorque );
				b2Joint_WakeBodies( m_jointId1 );
			}

			if ( ImGui::SliderFloat( "Speed", &m_motorSpeed, -20.0f, 20.0f, "%.0f" ) )
			{
				b2RevoluteJoint_SetTargetMotorSpeed( m_jointId1, m_motorSpeed );
				b2Joint_WakeBodies( m_jointId1 );
			}
			ImGui::PopItemWidth();
		}

		if ( ImGui::Checkbox( "Spring", &m_enableSpring ) )
		{
			b2RevoluteJoint_EnableSpring( m_jointId1, m_enableSpring );
			b2Joint_WakeBodies( m_jointId1 );
		}

		if ( m_enableSpring )
		{
			ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
			if ( ImGui::SliderFloat( "Hertz", &m_hertz, 0.0f, 30.0f, "%.1f" ) )
			{
				b2RevoluteJoint_SetSpringHertz( m_jointId1, m_hertz );
				b2Joint_WakeBodies( m_jointId1 );
			}

			if ( ImGui::SliderFloat( "Damping", &m_dampingRatio, 0.0f, 2.0f, "%.1f" ) )
			{
				b2RevoluteJoint_SetSpringDampingRatio( m_jointId1, m_dampingRatio );
				b2Joint_WakeBodies( m_jointId1 );
			}

			if ( ImGui::SliderFloat( "Degrees", &m_targetDegrees, -180.0f, 180.0f, "%.0f" ) )
			{
				b2RevoluteJoint_SetTargetAngle( m_jointId1, B2_PI * m_targetDegrees / 180.0f );
				b2Joint_WakeBodies( m_jointId1 );
			}
			ImGui::PopItemWidth();
		}

		return true;
	}

	void Step() override
	{
		Sample::Step();

		float angle1 = b2RevoluteJoint_GetCurrentAngle( m_jointId1 );
		DrawScreenTextLine( "Angle (Deg) 1 = %2.1f", angle1 );

		float torque1 = b2RevoluteJoint_GetCurrentMotorTorque( m_jointId1 );
		DrawScreenTextLine( "Motor Torque 1 = %4.1f", torque1 );

		float torque2 = b2RevoluteJoint_GetCurrentMotorTorque( m_jointId2 );
		DrawScreenTextLine( "Motor Torque 2 = %4.1f", torque2 );
	}

	static Sample* Create( SampleContext* context )
	{
		return new RevoluteJoint( context );
	}

	b2BodyId m_ball;
	b2JointId m_jointId1;
	b2JointId m_jointId2;
	float m_motorSpeed;
	float m_motorTorque;
	float m_hertz;
	float m_dampingRatio;
	float m_targetDegrees;
	bool m_enableSpring;
	bool m_enableMotor;
	bool m_enableLimit;
};

static int sampleRevolute = RegisterSample( "Joints", "Revolute", RevoluteJoint::Create );

class PrismaticJoint : public Sample
{
public:
	explicit PrismaticJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 8.0f };
			m_context->camera.zoom = 25.0f * 0.5f;
		}

		b2BodyId groundId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		m_enableSpring = false;
		m_enableLimit = true;
		m_enableMotor = false;
		m_motorSpeed = 2.0f;
		m_motorForce = 25.0f;
		m_hertz = 1.0f;
		m_dampingRatio = 0.5f;
		m_translation = 0.0f;

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.position = { 0.0f, 10.0f };
			bodyDef.type = b2_dynamicBody;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Polygon box = b2MakeBox( 0.5f, 2.0f );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2Pos pivot = { 0.0f, 9.0f };
			// b2Vec2 axis = b2Normalize({1.0f, 0.0f});
			b2Vec2 axis = b2Normalize( { 1.0f, 1.0f } );
			b2PrismaticJointDef jointDef = b2DefaultPrismaticJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameA.q = b2MakeRotFromUnitVector( axis );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.localFrameB.q = b2MakeRotFromUnitVector( axis );
			jointDef.base.drawScale = 2.0f;
			jointDef.motorSpeed = m_motorSpeed;
			jointDef.maxMotorForce = m_motorForce;
			jointDef.enableMotor = m_enableMotor;
			jointDef.lowerTranslation = -10.0f;
			jointDef.upperTranslation = 10.0f;
			jointDef.enableLimit = m_enableLimit;
			jointDef.enableSpring = m_enableSpring;
			jointDef.hertz = m_hertz;
			jointDef.dampingRatio = m_dampingRatio;

			m_jointId = b2CreatePrismaticJoint( m_worldId, &jointDef );
		}
	}

	bool DrawControls() override
	{
		if ( ImGui::Checkbox( "Limit", &m_enableLimit ) )
		{
			b2PrismaticJoint_EnableLimit( m_jointId, m_enableLimit );
			b2Joint_WakeBodies( m_jointId );
		}

		if ( ImGui::Checkbox( "Motor", &m_enableMotor ) )
		{
			b2PrismaticJoint_EnableMotor( m_jointId, m_enableMotor );
			b2Joint_WakeBodies( m_jointId );
		}

		if ( m_enableMotor )
		{
			ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
			if ( ImGui::SliderFloat( "Max Force", &m_motorForce, 0.0f, 200.0f, "%.0f" ) )
			{
				b2PrismaticJoint_SetMaxMotorForce( m_jointId, m_motorForce );
				b2Joint_WakeBodies( m_jointId );
			}

			if ( ImGui::SliderFloat( "Speed", &m_motorSpeed, -40.0f, 40.0f, "%.0f" ) )
			{
				b2PrismaticJoint_SetTargetMotorSpeed( m_jointId, m_motorSpeed );
				b2Joint_WakeBodies( m_jointId );
			}
			ImGui::PopItemWidth();
		}

		if ( ImGui::Checkbox( "Spring", &m_enableSpring ) )
		{
			b2PrismaticJoint_EnableSpring( m_jointId, m_enableSpring );
			b2Joint_WakeBodies( m_jointId );
		}

		if ( m_enableSpring )
		{
			ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
			if ( ImGui::SliderFloat( "Hertz", &m_hertz, 0.0f, 10.0f, "%.1f" ) )
			{
				b2PrismaticJoint_SetSpringHertz( m_jointId, m_hertz );
				b2Joint_WakeBodies( m_jointId );
			}

			if ( ImGui::SliderFloat( "Damping", &m_dampingRatio, 0.0f, 2.0f, "%.1f" ) )
			{
				b2PrismaticJoint_SetSpringDampingRatio( m_jointId, m_dampingRatio );
				b2Joint_WakeBodies( m_jointId );
			}

			if ( ImGui::SliderFloat( "Translation", &m_translation, -15.0f, 15.0f, "%.1f" ) )
			{
				b2PrismaticJoint_SetTargetTranslation( m_jointId, m_translation );
				b2Joint_WakeBodies( m_jointId );
			}
			ImGui::PopItemWidth();
		}

		return true;
	}

	void Step() override
	{
		Sample::Step();

		float force = b2PrismaticJoint_GetCurrentMotorForce( m_jointId );
		DrawScreenTextLine( "Motor Force = %4.1f", force );

		float translation = b2PrismaticJoint_GetCurrentTranslation( m_jointId );
		DrawScreenTextLine( "Translation = %4.1f", translation );

		float speed = b2PrismaticJoint_GetCurrentSpeed( m_jointId );
		DrawScreenTextLine( "Speed = %4.8f", speed );
	}

	static Sample* Create( SampleContext* context )
	{
		return new PrismaticJoint( context );
	}

	b2JointId m_jointId;
	float m_motorSpeed;
	float m_motorForce;
	float m_hertz;
	float m_dampingRatio;
	float m_translation;
	bool m_enableSpring;
	bool m_enableMotor;
	bool m_enableLimit;
};

static int samplePrismatic = RegisterSample( "Joints", "Prismatic", PrismaticJoint::Create );

class WheelJoint : public Sample
{
public:
	explicit WheelJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 10.0f };
			m_context->camera.zoom = 25.0f * 0.15f;
		}

		b2BodyId groundId;

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		m_enableSpring = true;
		m_enableLimit = true;
		m_enableMotor = true;
		m_motorSpeed = 2.0f;
		m_motorTorque = 5.0f;
		m_hertz = 1.0f;
		m_dampingRatio = 0.7f;

		b2BodyDef bodyDef = b2DefaultBodyDef();
		bodyDef.position = { 0.0f, 10.25f };
		bodyDef.type = b2_dynamicBody;
		b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

		b2ShapeDef shapeDef = b2DefaultShapeDef();
		b2Capsule capsule = { { 0.0f, -0.5f }, { 0.0f, 0.5f }, 0.5f };
		b2CreateCapsuleShape( bodyId, &shapeDef, &capsule );

		b2Pos pivot = { 0.0f, 10.0f };
		b2Vec2 axis = b2Normalize( { 1.0f, 1.0f } );
		b2WheelJointDef jointDef = b2DefaultWheelJointDef();
		jointDef.base.bodyIdA = groundId;
		jointDef.base.bodyIdB = bodyId;
		jointDef.base.localFrameA.q = b2MakeRotFromUnitVector( axis );
		jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
		jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
		jointDef.motorSpeed = m_motorSpeed;
		jointDef.maxMotorTorque = m_motorTorque;
		jointDef.enableMotor = m_enableMotor;
		jointDef.lowerTranslation = -3.0f;
		jointDef.upperTranslation = 3.0f;
		jointDef.enableLimit = m_enableLimit;
		jointDef.hertz = m_hertz;
		jointDef.dampingRatio = m_dampingRatio;

		m_jointId = b2CreateWheelJoint( m_worldId, &jointDef );
	}

	bool DrawControls() override
	{
		if ( ImGui::Checkbox( "Limit", &m_enableLimit ) )
		{
			b2WheelJoint_EnableLimit( m_jointId, m_enableLimit );
		}

		if ( ImGui::Checkbox( "Motor", &m_enableMotor ) )
		{
			b2WheelJoint_EnableMotor( m_jointId, m_enableMotor );
		}

		if ( m_enableMotor )
		{
			ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
			if ( ImGui::SliderFloat( "Torque", &m_motorTorque, 0.0f, 20.0f, "%.0f" ) )
			{
				b2WheelJoint_SetMaxMotorTorque( m_jointId, m_motorTorque );
			}

			if ( ImGui::SliderFloat( "Speed", &m_motorSpeed, -20.0f, 20.0f, "%.0f" ) )
			{
				b2WheelJoint_SetTargetMotorSpeed( m_jointId, m_motorSpeed );
			}
			ImGui::PopItemWidth();
		}

		if ( ImGui::Checkbox( "Spring", &m_enableSpring ) )
		{
			b2WheelJoint_EnableSpring( m_jointId, m_enableSpring );
		}

		if ( m_enableSpring )
		{
			ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
			if ( ImGui::SliderFloat( "Hertz", &m_hertz, 0.0f, 10.0f, "%.1f" ) )
			{
				b2WheelJoint_SetSpringHertz( m_jointId, m_hertz );
			}

			if ( ImGui::SliderFloat( "Damping", &m_dampingRatio, 0.0f, 2.0f, "%.1f" ) )
			{
				b2WheelJoint_SetSpringDampingRatio( m_jointId, m_dampingRatio );
			}
			ImGui::PopItemWidth();
		}

		return true;
	}

	void Step() override
	{
		Sample::Step();

		float torque = b2WheelJoint_GetCurrentMotorTorque( m_jointId );
		DrawScreenTextLine( "Motor Torque = %4.1f", torque );
	}

	static Sample* Create( SampleContext* context )
	{
		return new WheelJoint( context );
	}

	b2JointId m_jointId;
	float m_hertz;
	float m_dampingRatio;
	float m_motorSpeed;
	float m_motorTorque;
	bool m_enableSpring;
	bool m_enableMotor;
	bool m_enableLimit;
};

static int sampleWheel = RegisterSample( "Joints", "Wheel", WheelJoint::Create );

// A suspension bridge
class Bridge : public Sample
{
public:
	explicit Bridge( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.zoom = 25.0f * 2.5f;
		}

		b2BodyId groundId = b2_nullBodyId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		{
			m_constraintHertz = 60.0f;
			m_constraintDampingRatio = 0.0f;
			m_springHertz = 2.0f;
			m_springDampingRatio = 0.7f;
			m_frictionTorque = 200.0f;

			b2Polygon box = b2MakeBox( 0.5f, 0.125f );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 20.0f;

			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.enableMotor = true;
			jointDef.maxMotorTorque = m_frictionTorque;
			jointDef.enableSpring = true;
			jointDef.hertz = m_springHertz;
			jointDef.dampingRatio = m_springDampingRatio;

			int jointIndex = 0;

			float xbase = -80.0f;

			b2BodyId prevBodyId = groundId;
			for ( int i = 0; i < m_count; ++i )
			{
				b2BodyDef bodyDef = b2DefaultBodyDef();
				bodyDef.type = b2_dynamicBody;
				bodyDef.position = { xbase + 0.5f + 1.0f * i, 20.0f };
				bodyDef.linearDamping = 0.1f;
				bodyDef.angularDamping = 0.1f;

				m_bodyIds[i] = b2CreateBody( m_worldId, &bodyDef );

				b2CreatePolygonShape( m_bodyIds[i], &shapeDef, &box );

				b2Pos pivot = { xbase + 1.0f * i, 20.0f };
				jointDef.base.bodyIdA = prevBodyId;
				jointDef.base.bodyIdB = m_bodyIds[i];
				jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
				jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
				m_jointIds[jointIndex++] = b2CreateRevoluteJoint( m_worldId, &jointDef );

				prevBodyId = m_bodyIds[i];
			}

			b2Pos pivot = { xbase + 1.0f * m_count, 20.0f };
			jointDef.base.bodyIdA = prevBodyId;
			jointDef.base.bodyIdB = groundId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			m_jointIds[jointIndex++] = b2CreateRevoluteJoint( m_worldId, &jointDef );

			assert( jointIndex == m_count + 1 );
		}

		for ( int i = 0; i < 2; ++i )
		{
			b2Vec2 vertices[3] = { { -0.5f, 0.0f }, { 0.5f, 0.0f }, { 0.0f, 1.5f } };

			b2Hull hull = b2ComputeHull( vertices, 3 );
			b2Polygon triangle = b2MakePolygon( &hull, 0.0f );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 20.0f;

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { -8.0f + 8.0f * i, 22.0f };
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &triangle );
		}

		for ( int i = 0; i < 3; ++i )
		{
			b2Circle circle = { { 0.0f, 0.0f }, 0.5f };

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 20.0f;

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { -6.0f + 6.0f * i, 25.0f };
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreateCircleShape( bodyId, &shapeDef, &circle );
		}
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		bool updateFriction = ImGui::SliderFloat( "Joint Friction", &m_frictionTorque, 0.0f, 10000.0f, "%2.f" );
		if ( updateFriction )
		{
			for ( int i = 0; i <= m_count; ++i )
			{
				b2RevoluteJoint_SetMaxMotorTorque( m_jointIds[i], m_frictionTorque );
			}
		}

		if ( ImGui::SliderFloat( "Spring hertz", &m_springHertz, 0.0f, 30.0f, "%.0f" ) )
		{
			for ( int i = 0; i <= m_count; ++i )
			{
				b2RevoluteJoint_SetSpringHertz( m_jointIds[i], m_springHertz );
			}
		}

		if ( ImGui::SliderFloat( "Spring damping", &m_springDampingRatio, 0.0f, 2.0f, "%.1f" ) )
		{
			for ( int i = 0; i <= m_count; ++i )
			{
				b2RevoluteJoint_SetSpringDampingRatio( m_jointIds[i], m_springDampingRatio );
			}
		}

		if ( ImGui::SliderFloat( "Constraint hertz", &m_constraintHertz, 15.0f, 240.0f, "%.0f" ) )
		{
			for ( int i = 0; i <= m_count; ++i )
			{
				b2Joint_SetConstraintTuning( m_jointIds[i], m_constraintHertz, m_constraintDampingRatio );
			}
		}

		if ( ImGui::SliderFloat( "Constraint damping", &m_constraintDampingRatio, 0.0f, 10.0f, "%.1f" ) )
		{
			for ( int i = 0; i <= m_count; ++i )
			{
				b2Joint_SetConstraintTuning( m_jointIds[i], m_constraintHertz, m_constraintDampingRatio );
			}
		}

		ImGui::PopItemWidth();

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new Bridge( context );
	}

	static constexpr int m_count = 160;
	b2BodyId m_bodyIds[m_count];
	b2JointId m_jointIds[m_count + 1];
	float m_frictionTorque;
	float m_constraintHertz;
	float m_constraintDampingRatio;
	float m_springHertz;
	float m_springDampingRatio;
};

static int sampleBridgeIndex = RegisterSample( "Joints", "Bridge", Bridge::Create );

class BallAndChain : public Sample
{
public:
	explicit BallAndChain( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, -8.0f };
			m_context->camera.zoom = 27.5f;
		}

		b2BodyId groundId = b2_nullBodyId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		m_frictionTorque = 100.0f;

		{
			float hx = 0.5f;
			b2Capsule capsule = { { -hx, 0.0f }, { hx, 0.0f }, 0.125f };

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 20.0f;
			shapeDef.filter.categoryBits = 0x1;
			shapeDef.filter.maskBits = 0x2;
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();

			int jointIndex = 0;

			b2BodyId prevBodyId = groundId;
			for ( int i = 0; i < m_count; ++i )
			{
				b2BodyDef bodyDef = b2DefaultBodyDef();
				bodyDef.type = b2_dynamicBody;
				bodyDef.position = { ( 1.0f + 2.0f * i ) * hx, m_count * hx };
				b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
				b2CreateCapsuleShape( bodyId, &shapeDef, &capsule );

				b2Pos pivot = { ( 2.0f * i ) * hx, m_count * hx };
				jointDef.base.bodyIdA = prevBodyId;
				jointDef.base.bodyIdB = bodyId;
				jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
				jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
				jointDef.enableMotor = true;
				jointDef.maxMotorTorque = m_frictionTorque;
				jointDef.enableSpring = i > 0;
				jointDef.hertz = 4.0f;
				m_jointIds[jointIndex++] = b2CreateRevoluteJoint( m_worldId, &jointDef );

				prevBodyId = bodyId;
			}

			b2Circle circle = { { 0.0f, 0.0f }, 4.0f };

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { ( 1.0f + 2.0f * m_count ) * hx + circle.radius - hx, m_count * hx };
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			shapeDef.filter.categoryBits = 0x2;
			shapeDef.filter.maskBits = 0x1;
			b2CreateCircleShape( bodyId, &shapeDef, &circle );

			b2Pos pivot = { ( 2.0f * m_count ) * hx, m_count * hx };
			jointDef.base.bodyIdA = prevBodyId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.enableMotor = true;
			jointDef.maxMotorTorque = m_frictionTorque;
			jointDef.enableSpring = true;
			jointDef.hertz = 4.0f;
			m_jointIds[jointIndex++] = b2CreateRevoluteJoint( m_worldId, &jointDef );
			assert( jointIndex == m_count + 1 );
		}
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
		bool updateFriction = ImGui::SliderFloat( "Joint Friction", &m_frictionTorque, 0.0f, 1000.0f, "%2.f" );
		ImGui::PopItemWidth();
		if ( updateFriction )
		{
			for ( int i = 0; i <= m_count; ++i )
			{
				b2RevoluteJoint_SetMaxMotorTorque( m_jointIds[i], m_frictionTorque );
			}
		}

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new BallAndChain( context );
	}

	static constexpr int m_count = 30;
	b2JointId m_jointIds[m_count + 1];
	float m_frictionTorque;
};

static int sampleBallAndChainIndex = RegisterSample( "Joints", "Ball & Chain", BallAndChain::Create );

// This sample shows the limitations of an iterative solver. The cantilever sags even though the weld
// joint is stiff as possible.
class Cantilever : public Sample
{
public:
	enum
	{
		e_count = 8
	};

	explicit Cantilever( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 0.0f };
			m_context->camera.zoom = 25.0f * 0.35f;
		}

		b2BodyId groundId = b2_nullBodyId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		{
			m_linearHertz = 15.0f;
			m_linearDampingRatio = 0.5f;
			m_angularHertz = 5.0f;
			m_angularDampingRatio = 0.5f;
			m_gravityScale = 1.0f;
			m_collideConnected = false;

			float hx = 0.5f;
			b2Capsule capsule = { { -hx, 0.0f }, { hx, 0.0f }, 0.125f };
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 20.0f;

			b2WeldJointDef jointDef = b2DefaultWeldJointDef();

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.isAwake = false;

			b2BodyId prevBodyId = groundId;
			for ( int i = 0; i < e_count; ++i )
			{
				bodyDef.position = { ( 1.0f + 2.0f * i ) * hx, 0.0f };
				m_bodyIds[i] = b2CreateBody( m_worldId, &bodyDef );
				b2CreateCapsuleShape( m_bodyIds[i], &shapeDef, &capsule );

				b2Pos pivot = { ( 2.0f * i ) * hx, 0.0f };
				jointDef.base.bodyIdA = prevBodyId;
				jointDef.base.bodyIdB = m_bodyIds[i];
				jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
				jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
				jointDef.linearHertz = m_linearHertz;
				jointDef.linearDampingRatio = m_linearDampingRatio;
				jointDef.angularHertz = m_angularHertz;
				jointDef.angularDampingRatio = m_angularDampingRatio;
				jointDef.base.collideConnected = m_collideConnected;
				m_jointIds[i] = b2CreateWeldJoint( m_worldId, &jointDef );

				// Experimental tuning
				b2Joint_SetConstraintTuning( m_jointIds[i], 120.0f, 10.0f );

				prevBodyId = m_bodyIds[i];
			}

			m_tipId = prevBodyId;
		}
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Linear Hertz", &m_linearHertz, 0.0f, 20.0f, "%.0f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2WeldJoint_SetLinearHertz( m_jointIds[i], m_linearHertz );
			}
		}

		if ( ImGui::SliderFloat( "Linear Damping Ratio", &m_linearDampingRatio, 0.0f, 10.0f, "%.1f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2WeldJoint_SetLinearDampingRatio( m_jointIds[i], m_linearDampingRatio );
			}
		}

		if ( ImGui::SliderFloat( "Angular Hertz", &m_angularHertz, 0.0f, 20.0f, "%.0f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2WeldJoint_SetAngularHertz( m_jointIds[i], m_angularHertz );
			}
		}

		if ( ImGui::SliderFloat( "Angular Damping Ratio", &m_angularDampingRatio, 0.0f, 10.0f, "%.1f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2WeldJoint_SetAngularDampingRatio( m_jointIds[i], m_angularDampingRatio );
			}
		}

		if ( ImGui::SliderFloat( "Gravity Scale", &m_gravityScale, -1.0f, 1.0f, "%.1f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Body_SetGravityScale( m_bodyIds[i], m_gravityScale );
			}
		}

		ImGui::PopItemWidth();

		if ( ImGui::Checkbox( "Collide Connected", &m_collideConnected ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Joint_SetCollideConnected( m_jointIds[i], m_collideConnected );
			}
		}

		return true;
	}

	void Step() override
	{
		Sample::Step();

		b2Pos tipPosition = b2Body_GetPosition( m_tipId );
		DrawScreenTextLine( "tip-y = %.2f", tipPosition.y );
	}

	static Sample* Create( SampleContext* context )
	{
		return new Cantilever( context );
	}

	float m_linearHertz;
	float m_linearDampingRatio;
	float m_angularHertz;
	float m_angularDampingRatio;
	float m_gravityScale;
	b2BodyId m_tipId;
	b2BodyId m_bodyIds[e_count];
	b2JointId m_jointIds[e_count];
	bool m_collideConnected;
};

static int sampleCantileverIndex = RegisterSample( "Joints", "Cantilever", Cantilever::Create );

// This test ensures joints work correctly with bodies that have motion locks
class MotionLocks : public Sample
{
public:
	enum
	{
		e_count = 6
	};

	explicit MotionLocks( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 8.0f };
			m_context->camera.zoom = 25.0f * 0.7f;
		}

		b2BodyDef bodyDef = b2DefaultBodyDef();
		b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );

		m_motionLocks = { false, false, true };

		for ( int i = 0; i < e_count; ++i )
		{
			m_bodyIds[i] = b2_nullBodyId;
		}

		b2Pos position = { -12.5f, 10.0f };
		bodyDef.type = b2_dynamicBody;
		bodyDef.motionLocks = m_motionLocks;

		b2Polygon box = b2MakeBox( 1.0f, 1.0f );

		int index = 0;

		// distance joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			float length = 2.0f;
			b2Pos pivot1 = { position.x, position.y + 1.0f + length };
			b2Pos pivot2 = { position.x, position.y + 1.0f };
			b2DistanceJointDef jointDef = b2DefaultDistanceJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot1 );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot2 );
			jointDef.length = length;
			b2CreateDistanceJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// motor joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2MotorJointDef jointDef = b2DefaultMotorJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2ToVec2( position );
			jointDef.maxVelocityForce = 200.0f;
			jointDef.maxVelocityTorque = 200.0f;
			b2CreateMotorJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// prismatic joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2PrismaticJointDef jointDef = b2DefaultPrismaticJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			b2CreatePrismaticJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// revolute joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			b2CreateRevoluteJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// weld joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2WeldJointDef jointDef = b2DefaultWeldJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.angularHertz = 1.0f;
			jointDef.angularDampingRatio = 0.5f;
			jointDef.linearHertz = 1.0f;
			jointDef.linearDampingRatio = 0.5f;
			b2CreateWeldJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// wheel joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2WheelJointDef jointDef = b2DefaultWheelJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.hertz = 1.0f;
			jointDef.dampingRatio = 0.7f;
			jointDef.lowerTranslation = -1.0f;
			jointDef.upperTranslation = 1.0f;
			jointDef.enableLimit = true;
			jointDef.enableMotor = true;
			jointDef.maxMotorTorque = 10.0f;
			jointDef.motorSpeed = 1.0f;
			b2CreateWheelJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;
	}

	bool DrawControls() override
	{
		if ( ImGui::Checkbox( "Lock Linear X", &m_motionLocks.linearX ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Body_SetMotionLocks( m_bodyIds[i], m_motionLocks );
				b2Body_SetAwake( m_bodyIds[i], true );
			}
		}

		if ( ImGui::Checkbox( "Lock Linear Y", &m_motionLocks.linearY ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Body_SetMotionLocks( m_bodyIds[i], m_motionLocks );
				b2Body_SetAwake( m_bodyIds[i], true );
			}
		}

		if ( ImGui::Checkbox( "Lock Angular Z", &m_motionLocks.angularZ ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Body_SetMotionLocks( m_bodyIds[i], m_motionLocks );
				b2Body_SetAwake( m_bodyIds[i], true );
			}
		}

		if ( glfwGetKey( m_context->window, GLFW_KEY_L ) == GLFW_PRESS )
		{
			b2Body_ApplyLinearImpulseToCenter( m_bodyIds[0], { 100.0f, 0.0f }, true );
		}

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new MotionLocks( context );
	}

	b2BodyId m_bodyIds[e_count];
	b2MotionLocks m_motionLocks;
};

static int sampleMotionLocks = RegisterSample( "Joints", "Motion Locks", MotionLocks::Create );

// This sample shows how to break joints when the internal reaction force becomes large.
class BreakableJoint : public Sample
{
public:
	enum
	{
		e_count = 6
	};

	explicit BreakableJoint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 8.0f };
			m_context->camera.zoom = 25.0f * 0.7f;
		}

		b2BodyDef bodyDef = b2DefaultBodyDef();
		b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );

		b2ShapeDef shapeDef = b2DefaultShapeDef();
		b2Segment segment = { { -40.0f, 0.0f }, { 40.0f, 0.0f } };
		b2CreateSegmentShape( groundId, &shapeDef, &segment );

		for ( int i = 0; i < e_count; ++i )
		{
			m_jointIds[i] = b2_nullJointId;
		}

		b2Pos position = { -12.5f, 10.0f };
		bodyDef.type = b2_dynamicBody;
		bodyDef.enableSleep = false;

		b2Polygon box = b2MakeBox( 1.0f, 1.0f );

		int index = 0;

		// distance joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			float length = 2.0f;
			b2Pos pivot1 = { position.x, position.y + 1.0f + length };
			b2Pos pivot2 = { position.x, position.y + 1.0f };
			b2DistanceJointDef jointDef = b2DefaultDistanceJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot1 );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot2 );
			jointDef.length = length;
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateDistanceJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// motor joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2MotorJointDef jointDef = b2DefaultMotorJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2ToVec2( position );
			jointDef.maxVelocityForce = 1000.0f;
			jointDef.maxVelocityTorque = 20.0f;
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateMotorJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// prismatic joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2PrismaticJointDef jointDef = b2DefaultPrismaticJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreatePrismaticJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// revolute joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateRevoluteJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// weld joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2WeldJointDef jointDef = b2DefaultWeldJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateWeldJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		// wheel joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2WheelJointDef jointDef = b2DefaultWheelJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.hertz = 1.0f;
			jointDef.dampingRatio = 0.7f;
			jointDef.lowerTranslation = -1.0f;
			jointDef.upperTranslation = 1.0f;
			jointDef.enableLimit = true;
			jointDef.enableMotor = true;
			jointDef.maxMotorTorque = 10.0f;
			jointDef.motorSpeed = 1.0f;
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateWheelJoint( m_worldId, &jointDef );
		}

		position.x += 5.0f;
		++index;

		m_breakForce = 1000.0f;
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		ImGui::SliderFloat( "break force", &m_breakForce, 0.0f, 10000.0f, "%.1f" );

		b2Vec2 gravity = b2World_GetGravity( m_worldId );
		if ( ImGui::SliderFloat( "gravity", &gravity.y, -50.0f, 50.0f, "%.1f" ) )
		{
			b2World_SetGravity( m_worldId, gravity );
		}

		ImGui::PopItemWidth();

		return true;
	}

	void Step() override
	{
		for ( int i = 0; i < e_count; ++i )
		{
			if ( B2_IS_NULL( m_jointIds[i] ) )
			{
				continue;
			}

			b2Vec2 force = b2Joint_GetConstraintForce( m_jointIds[i] );
			if ( b2LengthSquared( force ) > m_breakForce * m_breakForce )
			{
				b2DestroyJoint( m_jointIds[i] );
				m_jointIds[i] = b2_nullJointId;
			}
			else
			{
				b2Transform localFrame = b2Joint_GetLocalFrameA( m_jointIds[i] );
				DrawString( m_draw, m_camera, b2ToPos( localFrame.p ), b2_colorWhite, "(%.1f, %.1f)", force.x, force.y );
			}
		}

		Sample::Step();
	}

	static Sample* Create( SampleContext* context )
	{
		return new BreakableJoint( context );
	}

	b2JointId m_jointIds[e_count];
	float m_breakForce;
};

static int sampleBreakableJoint = RegisterSample( "Joints", "Breakable", BreakableJoint::Create );

// This sample shows how to measure joint separation. This is the unresolved constraint error.
class JointSeparation : public Sample
{
public:
	enum
	{
		e_count = 5
	};

	explicit JointSeparation( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 8.0f };
			m_context->camera.zoom = 25.0f;
		}

		b2BodyDef bodyDef = b2DefaultBodyDef();
		b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );

		b2ShapeDef shapeDef = b2DefaultShapeDef();
		b2Segment segment = { { -40.0f, 0.0f }, { 40.0f, 0.0f } };
		b2CreateSegmentShape( groundId, &shapeDef, &segment );

		b2Pos position = { -20.0f, 10.0f };
		bodyDef.type = b2_dynamicBody;
		bodyDef.enableSleep = false;

		b2Polygon box = b2MakeBox( 1.0f, 1.0f );

		int index = 0;

		// distance joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			float length = 2.0f;
			b2Pos pivot1 = { position.x, position.y + 1.0f + length };
			b2Pos pivot2 = { position.x, position.y + 1.0f };
			b2DistanceJointDef jointDef = b2DefaultDistanceJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot1 );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot2 );
			jointDef.length = length;
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateDistanceJoint( m_worldId, &jointDef );
		}

		position.x += 10.0f;
		++index;

		// prismatic joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2PrismaticJointDef jointDef = b2DefaultPrismaticJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreatePrismaticJoint( m_worldId, &jointDef );
		}

		position.x += 10.0f;
		++index;

		// revolute joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateRevoluteJoint( m_worldId, &jointDef );
		}

		position.x += 10.0f;
		++index;

		// weld joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2WeldJointDef jointDef = b2DefaultWeldJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateWeldJoint( m_worldId, &jointDef );
		}

		position.x += 10.0f;
		++index;

		// wheel joint
		{
			assert( index < e_count );

			bodyDef.position = position;
			m_bodyIds[index] = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( m_bodyIds[index], &shapeDef, &box );

			b2Pos pivot = { position.x - 1.0f, position.y };
			b2WheelJointDef jointDef = b2DefaultWheelJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_bodyIds[index];
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.hertz = 1.0f;
			jointDef.dampingRatio = 0.7f;
			jointDef.lowerTranslation = -1.0f;
			jointDef.upperTranslation = 1.0f;
			jointDef.enableLimit = true;
			jointDef.enableMotor = true;
			jointDef.maxMotorTorque = 10.0f;
			jointDef.motorSpeed = 1.0f;
			jointDef.base.collideConnected = true;
			m_jointIds[index] = b2CreateWheelJoint( m_worldId, &jointDef );
		}

		m_impulse = 500.0f;
		m_jointHertz = 60.0f;
		m_jointDampingRatio = 2.0f;
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		b2Vec2 gravity = b2World_GetGravity( m_worldId );
		if ( ImGui::SliderFloat( "gravity", &gravity.y, -500.0f, 500.0f, "%.0f" ) )
		{
			b2World_SetGravity( m_worldId, gravity );
		}

		ImGui::SliderFloat( "magnitude", &m_impulse, 0.0f, 1000.0f, "%.0f" );

		if ( ImGui::SliderFloat( "hertz", &m_jointHertz, 15.0f, 120.0f, "%.0f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Joint_SetConstraintTuning( m_jointIds[i], m_jointHertz, m_jointDampingRatio );
			}
		}

		if ( ImGui::SliderFloat( "damping", &m_jointDampingRatio, 0.0f, 10.0f, "%.1f" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Joint_SetConstraintTuning( m_jointIds[i], m_jointHertz, m_jointDampingRatio );
			}
		}

		ImGui::PopItemWidth();

		if ( ImGui::Button( "impulse" ) )
		{
			for ( int i = 0; i < e_count; ++i )
			{
				b2Pos p = b2Body_GetWorldPoint( m_bodyIds[i], { 1.0f, 1.0f } );
				b2Body_ApplyLinearImpulse( m_bodyIds[i], { m_impulse, -m_impulse }, p, true );
			}
		}

		return true;
	}

	void Step() override
	{
		for ( int i = 0; i < e_count; ++i )
		{
			if ( B2_IS_NULL( m_jointIds[i] ) )
			{
				continue;
			}

			float linear = b2Joint_GetLinearSeparation( m_jointIds[i] );
			float angular = b2Joint_GetAngularSeparation( m_jointIds[i] );
			b2Transform localFrame = b2Joint_GetLocalFrameA( m_jointIds[i] );
			DrawString( m_draw, m_camera, b2ToPos( localFrame.p ), b2_colorWhite, "%.2f m, %.1f deg", linear,
						180.0f * angular / B2_PI );
		}

		Sample::Step();
	}

	static Sample* Create( SampleContext* context )
	{
		return new JointSeparation( context );
	}

	b2BodyId m_bodyIds[e_count];
	b2JointId m_jointIds[e_count];
	float m_impulse;
	float m_jointHertz;
	float m_jointDampingRatio;
};

static int sampleJointSeparation = RegisterSample( "Joints", "Separation", JointSeparation::Create );

// This shows how you can implement a constraint outside of Box2D
class UserConstraint : public Sample
{
public:
	explicit UserConstraint( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 3.0f, -1.0f };
			m_context->camera.zoom = 25.0f * 0.15f;
		}

		b2Polygon box = b2MakeBox( 1.0f, 0.5f );

		b2ShapeDef shapeDef = b2DefaultShapeDef();
		shapeDef.density = 20.0f;

		b2BodyDef bodyDef = b2DefaultBodyDef();
		bodyDef.type = b2_dynamicBody;
		bodyDef.gravityScale = 1.0f;
		bodyDef.angularDamping = 0.5f;
		bodyDef.linearDamping = 0.2f;
		m_bodyId = b2CreateBody( m_worldId, &bodyDef );
		b2CreatePolygonShape( m_bodyId, &shapeDef, &box );

		m_impulses[0] = 0.0f;
		m_impulses[1] = 0.0f;
	}

	void Step() override
	{
		Sample::Step();

		DrawTransform( m_draw, b2WorldTransform_identity, 1.0f );

		if ( m_context->pause )
		{
			return;
		}

		float timeStep = m_context->hertz > 0.0f ? 1.0f / m_context->hertz : 0.0f;
		if ( timeStep == 0.0f )
		{
			return;
		}

		float invTimeStep = m_context->hertz;

		static float hertz = 3.0f;
		static float zeta = 0.7f;
		static float maxForce = 1000.0f;
		float omega = 2.0f * B2_PI * hertz;
		float sigma = 2.0f * zeta + timeStep * omega;
		float s = timeStep * omega * sigma;
		float impulseCoefficient = 1.0f / ( 1.0f + s );
		float massCoefficient = s * impulseCoefficient;
		float biasCoefficient = omega / sigma;

		b2Vec2 localAnchors[2] = { { 1.0f, -0.5f }, { 1.0f, 0.5f } };
		float mass = b2Body_GetMass( m_bodyId );
		float invMass = mass < 0.0001f ? 0.0f : 1.0f / mass;
		float inertiaTensor = b2Body_GetRotationalInertia( m_bodyId );
		float invI = inertiaTensor < 0.0001f ? 0.0f : 1.0f / inertiaTensor;

		b2Vec2 vB = b2Body_GetLinearVelocity( m_bodyId );
		float omegaB = b2Body_GetAngularVelocity( m_bodyId );
		b2Pos pB = b2Body_GetWorldCenter( m_bodyId );

		for ( int i = 0; i < 2; ++i )
		{
			b2Pos anchorA = { 3.0f, 0.0f };
			b2Pos anchorB = b2Body_GetWorldPoint( m_bodyId, localAnchors[i] );

			b2Vec2 deltaAnchor = b2SubPos( anchorB, anchorA );

			float slackLength = 1.0f;
			float length = b2Length( deltaAnchor );
			float C = length - slackLength;
			if ( C < 0.0f || length < 0.001f )
			{
				DrawLine( m_draw, anchorA, anchorB, b2_colorLightCyan );
				m_impulses[i] = 0.0f;
				continue;
			}

			DrawLine( m_draw, anchorA, anchorB, b2_colorViolet );
			b2Vec2 axis = b2Normalize( deltaAnchor );

			b2Vec2 rB = b2SubPos( anchorB, pB );
			float Jb = b2Cross( rB, axis );
			float K = invMass + Jb * invI * Jb;
			float invK = K < 0.0001f ? 0.0f : 1.0f / K;

			float Cdot = b2Dot( vB, axis ) + Jb * omegaB;
			float impulse = -massCoefficient * invK * ( Cdot + biasCoefficient * C );
			float appliedImpulse = b2ClampFloat( impulse, -maxForce * timeStep, 0.0f );

			vB = b2MulAdd( vB, invMass * appliedImpulse, axis );
			omegaB += appliedImpulse * invI * Jb;

			m_impulses[i] = appliedImpulse;
		}

		b2Body_SetLinearVelocity( m_bodyId, vB );
		b2Body_SetAngularVelocity( m_bodyId, omegaB );

		DrawScreenTextLine( "forces = %g, %g", m_impulses[0] * invTimeStep, m_impulses[1] * invTimeStep );
	}

	static Sample* Create( SampleContext* context )
	{
		return new UserConstraint( context );
	}

	b2BodyId m_bodyId;
	float m_impulses[2];
};

static int sampleUserConstraintIndex = RegisterSample( "Joints", "User Constraint", UserConstraint::Create );

// This is a fun demo that shows off the wheel joint
class Driving : public Sample
{
public:
	explicit Driving( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center.y = 5.0f;
			m_context->camera.zoom = 25.0f * 0.4f;
			m_context->debugDraw.drawJoints = false;
		}

		b2BodyId groundId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );

			b2Vec2 points[25];
			int count = 24;

			// fill in reverse to match line list convention
			points[count--] = { -20.0f, -20.0f };
			points[count--] = { -20.0f, 0.0f };
			points[count--] = { 20.0f, 0.0f };

			float hs[10] = { 0.25f, 1.0f, 4.0f, 0.0f, 0.0f, -1.0f, -2.0f, -2.0f, -1.25f, 0.0f };
			float x = 20.0f, dx = 5.0f;

			for ( int j = 0; j < 2; ++j )
			{
				for ( int i = 0; i < 10; ++i )
				{
					float y2 = hs[i];
					points[count--] = { x + dx, y2 };
					x += dx;
				}
			}

			// flat before bridge
			points[count--] = { x + 40.0f, 0.0f };
			points[count--] = { x + 40.0f, -20.0f };

			assert( count == -1 );

			b2ChainDef chainDef = b2DefaultChainDef();
			chainDef.points = points;
			chainDef.pointCount = 25;
			chainDef.isLoop = true;
			b2CreateChain( groundId, &chainDef );

			// flat after bridge
			x += 80.0f;
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { x, 0.0f }, { x + 40.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			// jump ramp
			x += 40.0f;
			segment = { { x, 0.0f }, { x + 10.0f, 5.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			// final corner
			x += 20.0f;
			segment = { { x, 0.0f }, { x + 40.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			x += 40.0f;
			segment = { { x, 0.0f }, { x, 20.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		// Teeter
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.position = { 140.0f, 1.0f };
			bodyDef.angularVelocity = 1.0f;
			bodyDef.type = b2_dynamicBody;
			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Polygon box = b2MakeBox( 10.0f, 0.25f );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			b2Pos pivot = bodyDef.position;
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = bodyId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.lowerAngle = -8.0f * B2_PI / 180.0f;
			jointDef.upperAngle = 8.0f * B2_PI / 180.0f;
			jointDef.enableLimit = true;
			b2CreateRevoluteJoint( m_worldId, &jointDef );
		}

		// Bridge
		{
			int N = 20;
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Capsule capsule = { { -1.0f, 0.0f }, { 1.0f, 0.0f }, 0.125f };

			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();

			b2BodyId prevBodyId = groundId;
			for ( int i = 0; i < N; ++i )
			{
				b2BodyDef bodyDef = b2DefaultBodyDef();
				bodyDef.type = b2_dynamicBody;
				bodyDef.position = { 161.0f + 2.0f * i, -0.125f };
				b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
				b2CreateCapsuleShape( bodyId, &shapeDef, &capsule );

				b2Pos pivot = { 160.0f + 2.0f * i, -0.125f };
				jointDef.base.bodyIdA = prevBodyId;
				jointDef.base.bodyIdB = bodyId;
				jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
				jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
				b2CreateRevoluteJoint( m_worldId, &jointDef );

				prevBodyId = bodyId;
			}

			b2Pos pivot = { 160.0f + 2.0f * N, -0.125f };
			jointDef.base.bodyIdA = prevBodyId;
			jointDef.base.bodyIdB = groundId;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
			jointDef.enableMotor = true;
			jointDef.maxMotorTorque = 50.0f;
			b2CreateRevoluteJoint( m_worldId, &jointDef );
		}

		// Boxes
		{
			b2Polygon box = b2MakeBox( 0.5f, 0.5f );

			b2BodyId bodyId;
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.material.friction = 0.25f;
			shapeDef.material.restitution = 0.25f;
			shapeDef.density = 0.25f;

			bodyDef.position = { 230.0f, 0.5f };
			bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			bodyDef.position = { 230.0f, 1.5f };
			bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			bodyDef.position = { 230.0f, 2.5f };
			bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			bodyDef.position = { 230.0f, 3.5f };
			bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			bodyDef.position = { 230.0f, 4.5f };
			bodyId = b2CreateBody( m_worldId, &bodyDef );
			b2CreatePolygonShape( bodyId, &shapeDef, &box );
		}

		// Car

		m_throttle = 0.0f;
		m_speed = 35.0f;
		m_torque = 5.0f;
		m_hertz = 5.0f;
		m_dampingRatio = 0.7f;

		m_car.Spawn( m_worldId, { 0.0f, 0.0f }, 1.0f, m_hertz, m_dampingRatio, m_torque, nullptr );
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );
		if ( ImGui::SliderFloat( "Spring Hertz", &m_hertz, 0.0f, 20.0f, "%.0f" ) )
		{
			m_car.SetHertz( m_hertz );
		}

		if ( ImGui::SliderFloat( "Damping Ratio", &m_dampingRatio, 0.0f, 10.0f, "%.1f" ) )
		{
			m_car.SetDampingRadio( m_dampingRatio );
		}

		if ( ImGui::SliderFloat( "Speed", &m_speed, 0.0f, 50.0f, "%.0f" ) )
		{
			m_car.SetSpeed( m_throttle * m_speed );
		}

		if ( ImGui::SliderFloat( "Torque", &m_torque, 0.0f, 10.0f, "%.1f" ) )
		{
			m_car.SetTorque( m_torque );
		}
		ImGui::PopItemWidth();

		return true;
	}

	void Step() override
	{
		if ( glfwGetKey( m_context->window, GLFW_KEY_A ) == GLFW_PRESS )
		{
			m_throttle = 1.0f;
			m_car.SetSpeed( m_speed );
		}

		if ( glfwGetKey( m_context->window, GLFW_KEY_S ) == GLFW_PRESS )
		{
			m_throttle = 0.0f;
			m_car.SetSpeed( 0.0f );
		}

		if ( glfwGetKey( m_context->window, GLFW_KEY_D ) == GLFW_PRESS )
		{
			m_throttle = -1.0f;
			m_car.SetSpeed( -m_speed );
		}

		DrawScreenTextLine( "Keys: left = a, brake = s, right = d" );

		b2Vec2 linearVelocity = b2Body_GetLinearVelocity( m_car.m_chassisId );
		float kph = linearVelocity.x * 3.6f;
		DrawScreenTextLine( "speed in kph: %.2g", kph );

		b2Pos carPosition = b2Body_GetPosition( m_car.m_chassisId );
		m_context->camera.center.x = carPosition.x;

		Sample::Step();
	}

	static Sample* Create( SampleContext* context )
	{
		return new Driving( context );
	}

	Car m_car;

	float m_throttle;
	float m_hertz;
	float m_dampingRatio;
	float m_torque;
	float m_speed;
};

static int sampleDriving = RegisterSample( "Joints", "Driving", Driving::Create );

class Ragdoll : public Sample
{
public:
	explicit Ragdoll( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 12.0f };
			m_context->camera.zoom = 16.0f;

			// m_context->camera.m_center = { 0.0f, 26.0f };
			// m_context->camera.m_zoom = 1.0f;
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		m_jointFrictionTorque = 0.03f;
		m_jointHertz = 5.0f;
		m_jointDampingRatio = 0.5f;

		m_human = {};

		Spawn();

		b2World_SetContactTuning( m_worldId, 240.0f, 0.0f, 2.0f );
	}

	void Spawn()
	{
		CreateHuman( &m_human, m_worldId, { 0.0f, 25.0f }, 1.0f, m_jointFrictionTorque, m_jointHertz, m_jointDampingRatio, 1,
					 nullptr, false );
		// Human_ApplyRandomAngularImpulse( &m_human, 10.0f );
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Friction", &m_jointFrictionTorque, 0.0f, 1.0f, "%3.2f" ) )
		{
			Human_SetJointFrictionTorque( &m_human, m_jointFrictionTorque );
		}

		if ( ImGui::SliderFloat( "Hertz", &m_jointHertz, 0.0f, 10.0f, "%3.1f" ) )
		{
			Human_SetJointSpringHertz( &m_human, m_jointHertz );
		}

		if ( ImGui::SliderFloat( "Damping", &m_jointDampingRatio, 0.0f, 4.0f, "%3.1f" ) )
		{
			Human_SetJointDampingRatio( &m_human, m_jointDampingRatio );
		}

		ImGui::PopItemWidth();

		if ( ImGui::Button( "Respawn" ) )
		{
			DestroyHuman( &m_human );
			Spawn();
		}

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new Ragdoll( context );
	}

	Human m_human;
	float m_jointFrictionTorque;
	float m_jointHertz;
	float m_jointDampingRatio;
};

static int sampleRagdoll = RegisterSample( "Joints", "Ragdoll", Ragdoll::Create );

class SoftBody : public Sample
{
public:
	explicit SoftBody( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 5.0f };
			m_context->camera.zoom = 25.0f * 0.25f;
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		m_donut.Create( m_worldId, { 0.0f, 10.0f }, 2.0f, 0, false, nullptr );
	}

	static Sample* Create( SampleContext* context )
	{
		return new SoftBody( context );
	}

	Donut m_donut;
};

static int sampleDonut = RegisterSample( "Joints", "Soft Body", SoftBody::Create );

class DoohickeyFarm : public Sample
{
public:
	explicit DoohickeyFarm( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 5.0f };
			m_context->camera.zoom = 25.0f * 0.35f;
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			b2Polygon box = b2MakeOffsetBox( 1.0f, 1.0f, { 0.0f, 1.0f }, b2Rot_identity );
			b2CreatePolygonShape( groundId, &shapeDef, &box );
		}

		float y = 4.0f;
		for ( int i = 0; i < 4; ++i )
		{
			Doohickey doohickey;
			doohickey.Spawn( m_worldId, { 0.0f, y }, 0.5f );
			y += 2.0f;
		}
	}

	void Step() override
	{
		Sample::Step();
	}

	static Sample* Create( SampleContext* context )
	{
		return new DoohickeyFarm( context );
	}
};

static int sampleDoohickey = RegisterSample( "Joints", "Doohickey", DoohickeyFarm::Create );

class ScissorLift : public Sample
{
public:
	explicit ScissorLift( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 9.0f };
			m_context->camera.zoom = 25.0f * 0.4f;
		}

		// Need 8 sub-steps for smoother operation
		m_context->subStepCount = 8;

		b2BodyId groundId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		b2BodyDef bodyDef = b2DefaultBodyDef();
		bodyDef.type = b2_dynamicBody;
		bodyDef.sleepThreshold = 0.01f;

		b2ShapeDef shapeDef = b2DefaultShapeDef();
		b2Capsule capsule = { { -2.5f, 0.0f }, { 2.5f, 0.0f }, 0.15f };

		b2BodyId baseId1 = groundId;
		b2BodyId baseId2 = groundId;
		b2Vec2 baseAnchor1 = { -2.5f, 0.2f };
		b2Vec2 baseAnchor2 = { 2.5f, 0.2f };
		float y = 0.5f;

		b2BodyId linkId1;
		int N = 3;

		float constraintDampingRatio = 20.0f;
		float constraintHertz = 240.0f;

		for ( int i = 0; i < N; ++i )
		{
			bodyDef.position = { 0.0f, y };
			bodyDef.rotation = b2MakeRot( 0.15f );
			b2BodyId bodyId1 = b2CreateBody( m_worldId, &bodyDef );
			b2CreateCapsuleShape( bodyId1, &shapeDef, &capsule );

			bodyDef.position = { 0.0f, y };
			bodyDef.rotation = b2MakeRot( -0.15f );

			b2BodyId bodyId2 = b2CreateBody( m_worldId, &bodyDef );
			b2CreateCapsuleShape( bodyId2, &shapeDef, &capsule );

			if ( i == 1 )
			{
				linkId1 = bodyId2;
			}

			b2RevoluteJointDef revoluteDef = b2DefaultRevoluteJointDef();

			// left pin
			revoluteDef.base.bodyIdA = baseId1;
			revoluteDef.base.bodyIdB = bodyId1;
			revoluteDef.base.localFrameA.p = baseAnchor1;
			revoluteDef.base.localFrameB.p = { -2.5f, 0.0f };
			revoluteDef.base.collideConnected = ( i == 0 ) ? true : false;
			revoluteDef.base.constraintDampingRatio = constraintDampingRatio;
			revoluteDef.base.constraintHertz = constraintHertz;

			b2CreateRevoluteJoint( m_worldId, &revoluteDef );

			// right pin
			if ( i == 0 )
			{
				b2WheelJointDef wheelDef = b2DefaultWheelJointDef();
				wheelDef.base.bodyIdA = baseId2;
				wheelDef.base.bodyIdB = bodyId2;
				wheelDef.base.localFrameA.p = baseAnchor2;
				wheelDef.base.localFrameB.p = { 2.5f, 0.0f };
				wheelDef.enableSpring = false;
				wheelDef.base.collideConnected = true;
				wheelDef.base.constraintDampingRatio = constraintDampingRatio;
				wheelDef.base.constraintHertz = constraintHertz;

				b2CreateWheelJoint( m_worldId, &wheelDef );
			}
			else
			{
				revoluteDef.base.bodyIdA = baseId2;
				revoluteDef.base.bodyIdB = bodyId2;
				revoluteDef.base.localFrameA.p = baseAnchor2;
				revoluteDef.base.localFrameB.p = { 2.5f, 0.0f };
				revoluteDef.base.collideConnected = false;
				revoluteDef.base.constraintDampingRatio = constraintDampingRatio;
				revoluteDef.base.constraintHertz = constraintHertz;

				b2CreateRevoluteJoint( m_worldId, &revoluteDef );
			}

			// middle pin
			revoluteDef.base.bodyIdA = bodyId1;
			revoluteDef.base.bodyIdB = bodyId2;
			revoluteDef.base.localFrameA.p = { 0.0f, 0.0f };
			revoluteDef.base.localFrameB.p = { 0.0f, 0.0f };
			revoluteDef.base.collideConnected = false;
			revoluteDef.base.constraintDampingRatio = constraintDampingRatio;
			revoluteDef.base.constraintHertz = constraintHertz;

			b2CreateRevoluteJoint( m_worldId, &revoluteDef );

			baseId1 = bodyId2;
			baseId2 = bodyId1;
			baseAnchor1 = { -2.5f, 0.0f };
			baseAnchor2 = { 2.5f, 0.0f };
			y += 1.0f;
		}

		bodyDef.position = { 0.0f, y };
		bodyDef.rotation = b2Rot_identity;
		b2BodyId platformId = b2CreateBody( m_worldId, &bodyDef );

		b2Polygon box = b2MakeBox( 3.0f, 0.2f );
		b2CreatePolygonShape( platformId, &shapeDef, &box );

		// left pin
		b2RevoluteJointDef revoluteDef = b2DefaultRevoluteJointDef();
		revoluteDef.base.bodyIdA = platformId;
		revoluteDef.base.bodyIdB = baseId1;
		revoluteDef.base.localFrameA.p = { -2.5f, -0.4f };
		revoluteDef.base.localFrameB.p = baseAnchor1;
		revoluteDef.base.collideConnected = true;
		revoluteDef.base.constraintDampingRatio = constraintDampingRatio;
		revoluteDef.base.constraintHertz = constraintHertz;
		b2CreateRevoluteJoint( m_worldId, &revoluteDef );

		// right pin
		b2WheelJointDef wheelDef = b2DefaultWheelJointDef();
		wheelDef.base.bodyIdA = platformId;
		wheelDef.base.bodyIdB = baseId2;
		wheelDef.base.localFrameA.p = { 2.5f, -0.4f };
		wheelDef.base.localFrameB.p = baseAnchor2;
		wheelDef.enableSpring = false;
		wheelDef.base.collideConnected = true;
		wheelDef.base.constraintDampingRatio = constraintDampingRatio;
		wheelDef.base.constraintHertz = constraintHertz;
		b2CreateWheelJoint( m_worldId, &wheelDef );

		m_enableMotor = false;
		m_motorSpeed = 0.25f;
		m_motorForce = 2000.0f;

		b2DistanceJointDef distanceDef = b2DefaultDistanceJointDef();
		distanceDef.base.bodyIdA = groundId;
		distanceDef.base.bodyIdB = linkId1;
		distanceDef.base.localFrameA.p = { -2.5f, 0.2f };
		distanceDef.base.localFrameB.p = { 0.5f, 0.0f };
		distanceDef.enableSpring = true;
		distanceDef.minLength = 0.2f;
		distanceDef.maxLength = 5.5f;
		distanceDef.enableLimit = true;
		distanceDef.enableMotor = m_enableMotor;
		distanceDef.motorSpeed = m_motorSpeed;
		distanceDef.maxMotorForce = m_motorForce;
		m_liftJointId = b2CreateDistanceJoint( m_worldId, &distanceDef );

		Car car;
		car.Spawn( m_worldId, { 0.0f, y + 2.0f }, 1.0f, 3.0f, 0.7f, 0.0f, nullptr );
	}

	bool DrawControls() override
	{
		if ( ImGui::Checkbox( "Motor", &m_enableMotor ) )
		{
			b2DistanceJoint_EnableMotor( m_liftJointId, m_enableMotor );
			b2Joint_WakeBodies( m_liftJointId );
		}

		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Max Force", &m_motorForce, 0.0f, 3000.0f, "%.0f" ) )
		{
			b2DistanceJoint_SetMaxMotorForce( m_liftJointId, m_motorForce );
			b2Joint_WakeBodies( m_liftJointId );
		}

		if ( ImGui::SliderFloat( "Speed", &m_motorSpeed, -0.3f, 0.3f, "%.2f" ) )
		{
			b2DistanceJoint_SetTargetMotorSpeed( m_liftJointId, m_motorSpeed );
			b2Joint_WakeBodies( m_liftJointId );
		}

		ImGui::PopItemWidth();

		return true;
	}

	void Step() override
	{
		Sample::Step();
	}

	static Sample* Create( SampleContext* context )
	{
		return new ScissorLift( context );
	}

	b2JointId m_liftJointId;
	float m_motorForce;
	float m_motorSpeed;
	bool m_enableMotor;
};

static int sampleScissorLift = RegisterSample( "Joints", "Scissor Lift", ScissorLift::Create );

class GearLift : public Sample
{
public:
	explicit GearLift( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 6.0f };
			m_context->camera.zoom = 7.0f;
			m_context->debugDraw.drawJoints = false;
		}

		b2BodyId groundId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			groundId = b2CreateBody( m_worldId, &bodyDef );

			const char* path =
				"m 63.500002,201.08333 103.187498,0 1e-5,-37.04166 h -2.64584 l 0,34.39583 h -42.33333 v -2.64583 l "
				"-2.64584,-1e-5 v -2.64583 h -2.64583 v -2.64584 h -2.64584 v -2.64583 H 111.125 v -2.64583 h -2.64583 v "
				"-2.64583 h -2.64583 v -2.64584 l -2.64584,1e-5 v -2.64583 l -2.64583,-1e-5 V 174.625 h -2.645834 v -2.64584 l "
				"-2.645833,1e-5 v -2.64584 H 92.60417 v -2.64583 h -2.645834 v -2.64583 l -26.458334,0 0,37.04166";

			b2Vec2 points[128];

			b2Vec2 offset = { -120.0f, -200.0f };
			float scale = 0.2f;
			int count = ParsePath( path, offset, points, 64, scale, false );

			b2SurfaceMaterial material = b2DefaultSurfaceMaterial();
			material.customColor = b2_colorDarkSeaGreen;

			b2ChainDef chainDef = b2DefaultChainDef();
			chainDef.points = points;
			chainDef.pointCount = count;
			chainDef.isLoop = true;
			chainDef.materials = &material;
			chainDef.materialCount = 1;

			b2CreateChain( groundId, &chainDef );
		}

		float gearRadius = 1.0f;
		float toothHalfWidth = 0.09f;
		float toothHalfHeight = 0.06f;
		float toothRadius = 0.03f;
		float linkHalfLength = 0.07f;
		float linkRadius = 0.05f;
		float linkCount = 40;
		float doorHalfHeight = 1.5f;

		b2Pos gearPosition1 = { -4.25f, 9.75f };
		b2Pos gearPosition2 = gearPosition1 + b2Vec2{ 2.0f, 1.0f };
		b2Pos linkAttachPosition = gearPosition2 + b2Vec2{ gearRadius + 2.0f * toothHalfWidth + toothRadius, 0.0f };
		b2Pos doorPosition = linkAttachPosition - b2Vec2{ 0.0f, 2.0f * linkCount * linkHalfLength + doorHalfHeight };

		{
			b2Pos position = gearPosition1;
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = position;

			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.material.friction = 0.1f;
			shapeDef.material.customColor = b2_colorSaddleBrown;
			b2Circle circle = { b2Vec2_zero, gearRadius };
			b2CreateCircleShape( bodyId, &shapeDef, &circle );

			int count = 16;
			float deltaAngle = 2.0f * B2_PI / 16;
			b2Rot dq = b2MakeRot( deltaAngle );
			b2Vec2 center = { gearRadius + toothHalfHeight, 0.0f };
			b2Rot rotation = b2Rot_identity;

			for ( int i = 0; i < count; ++i )
			{
				b2Polygon tooth = b2MakeOffsetRoundedBox( toothHalfWidth, toothHalfHeight, center, rotation, toothRadius );
				shapeDef.material.customColor = b2_colorGray;
				b2CreatePolygonShape( bodyId, &shapeDef, &tooth );

				rotation = b2MulRot( dq, rotation );
				center = b2RotateVector( rotation, { gearRadius + toothHalfHeight, 0.0f } );
			}

			b2RevoluteJointDef revoluteDef = b2DefaultRevoluteJointDef();

			m_motorTorque = 80.0f;
			m_motorSpeed = 0.0f;
			m_enableMotor = true;

			revoluteDef.base.bodyIdA = groundId;
			revoluteDef.base.bodyIdB = bodyId;
			revoluteDef.base.localFrameA.p = b2Body_GetLocalPoint( groundId, position );
			revoluteDef.base.localFrameB.p = b2Vec2_zero;
			revoluteDef.enableMotor = m_enableMotor;
			revoluteDef.maxMotorTorque = m_motorTorque;
			revoluteDef.motorSpeed = m_motorSpeed;
			m_driverId = b2CreateRevoluteJoint( m_worldId, &revoluteDef );
		}

		b2BodyId followerId;

		{
			b2Pos position = gearPosition2;
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = position;

			followerId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.material.friction = 0.1f;
			shapeDef.material.customColor = b2_colorSaddleBrown;
			b2Circle circle = { b2Vec2_zero, gearRadius };
			b2CreateCircleShape( followerId, &shapeDef, &circle );

			int count = 16;
			float deltaAngle = 2.0f * B2_PI / 16;
			b2Rot dq = b2MakeRot( deltaAngle );
			b2Vec2 center = { gearRadius + toothHalfWidth, 0.0f };
			b2Rot rotation = b2Rot_identity;

			for ( int i = 0; i < count; ++i )
			{
				b2Polygon tooth = b2MakeOffsetRoundedBox( toothHalfWidth, toothHalfHeight, center, rotation, toothRadius );
				shapeDef.material.customColor = b2_colorGray;
				b2CreatePolygonShape( followerId, &shapeDef, &tooth );

				rotation = b2MulRot( dq, rotation );
				center = b2RotateVector( rotation, { gearRadius + toothHalfWidth, 0.0f } );
			}

			b2RevoluteJointDef revoluteDef = b2DefaultRevoluteJointDef();

			revoluteDef.base.bodyIdA = groundId;
			revoluteDef.base.bodyIdB = followerId;
			revoluteDef.base.localFrameA.p = b2Body_GetLocalPoint( groundId, position );
			revoluteDef.base.localFrameA.q = b2MakeRot( 0.25f * B2_PI );
			revoluteDef.base.localFrameB.p = b2Vec2_zero;
			revoluteDef.enableMotor = true;
			revoluteDef.maxMotorTorque = 0.5f;
			revoluteDef.lowerAngle = -0.3f * B2_PI;
			revoluteDef.upperAngle = 0.8f * B2_PI;
			revoluteDef.enableLimit = true;
			b2CreateRevoluteJoint( m_worldId, &revoluteDef );
		}

		b2BodyId lastLinkId;
		{
			b2Capsule capsule = { { 0.0f, -linkHalfLength }, { 0.0f, linkHalfLength }, linkRadius };

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 2.0f;
			shapeDef.material.customColor = b2_colorLightSteelBlue;

			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.maxMotorTorque = 0.05f;
			jointDef.enableMotor = true;

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			b2Pos position = linkAttachPosition + b2Vec2{ 0.0f, -linkHalfLength };

			int count = 40;
			b2BodyId prevBodyId = followerId;
			for ( int i = 0; i < count; ++i )
			{
				bodyDef.position = position;

				b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
				b2CreateCapsuleShape( bodyId, &shapeDef, &capsule );

				b2Pos pivot = { position.x, position.y + linkHalfLength };
				jointDef.base.bodyIdA = prevBodyId;
				jointDef.base.bodyIdB = bodyId;
				jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, pivot );
				jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, pivot );
				jointDef.base.drawScale = 0.2f;
				b2CreateRevoluteJoint( m_worldId, &jointDef );

				position.y -= 2.0f * linkHalfLength;
				prevBodyId = bodyId;
			}

			lastLinkId = prevBodyId;
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = doorPosition;

			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon box = b2MakeBox( 0.15f, doorHalfHeight );
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.material.friction = 0.1f;
			shapeDef.material.customColor = b2_colorDarkCyan;
			b2CreatePolygonShape( bodyId, &shapeDef, &box );

			{
				b2Pos pivot = doorPosition + b2Vec2{ 0.0f, doorHalfHeight };
				b2RevoluteJointDef revoluteDef = b2DefaultRevoluteJointDef();
				revoluteDef.base.bodyIdA = lastLinkId;
				revoluteDef.base.bodyIdB = bodyId;
				revoluteDef.base.localFrameA.p = b2Body_GetLocalPoint( lastLinkId, pivot );
				revoluteDef.base.localFrameB.p = { 0.0f, doorHalfHeight };
				revoluteDef.enableMotor = true;
				revoluteDef.maxMotorTorque = 0.05f;
				b2CreateRevoluteJoint( m_worldId, &revoluteDef );
			}

			{
				b2Vec2 localAxis = { 0.0f, 1.0f };
				b2PrismaticJointDef jointDef = b2DefaultPrismaticJointDef();
				jointDef.base.bodyIdA = groundId;
				jointDef.base.bodyIdB = bodyId;
				jointDef.base.localFrameA.p = b2Body_GetLocalPoint( groundId, doorPosition );
				jointDef.base.localFrameA.q = b2MakeRotFromUnitVector( localAxis );
				jointDef.base.localFrameB.p = b2Vec2_zero;
				jointDef.base.localFrameB.q = b2MakeRotFromUnitVector( localAxis );
				jointDef.maxMotorForce = 0.2f;
				jointDef.enableMotor = true;
				jointDef.base.collideConnected = true;
				b2CreatePrismaticJoint( m_worldId, &jointDef );
			}
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.material.rollingResistance = 0.3f;

			b2HexColor colors[5] = {
				b2_colorGray, b2_colorGainsboro, b2_colorLightGray, b2_colorLightSlateGray, b2_colorDarkGray,
			};

			float y = 4.25f;
			int xCount = 10, yCount = 20;
			for ( int i = 0; i < yCount; ++i )
			{
				float x = -3.15f;
				for ( int j = 0; j < xCount; ++j )
				{
					bodyDef.position = { x, y };
					b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );
					b2Polygon poly = RandomPolygon( 0.1f );
					poly.radius = RandomFloatRange( 0.01f, 0.02f );

					int colorIndex = RandomIntRange( 0, 4 );
					shapeDef.material.customColor = colors[colorIndex];

					b2CreatePolygonShape( bodyId, &shapeDef, &poly );
					x += 0.2f;
				}

				y += 0.2f;
			}
		}
	}

	bool DrawControls() override
	{
		if ( ImGui::Checkbox( "Motor", &m_enableMotor ) )
		{
			b2RevoluteJoint_EnableMotor( m_driverId, m_enableMotor );
			b2Joint_WakeBodies( m_driverId );
		}

		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Max Torque", &m_motorTorque, 0.0f, 100.0f, "%.0f" ) )
		{
			b2RevoluteJoint_SetMaxMotorTorque( m_driverId, m_motorTorque );
			b2Joint_WakeBodies( m_driverId );
		}

		if ( ImGui::SliderFloat( "Speed", &m_motorSpeed, -0.3f, 0.3f, "%.2f" ) )
		{
			b2RevoluteJoint_SetTargetMotorSpeed( m_driverId, m_motorSpeed );
			b2Joint_WakeBodies( m_driverId );
		}

		ImGui::PopItemWidth();

		return true;
	}

	void Step() override
	{
		if ( glfwGetKey( m_context->window, GLFW_KEY_A ) )
		{
			m_motorSpeed = b2MaxFloat( -0.3f, m_motorSpeed - 0.01f );
			b2RevoluteJoint_SetTargetMotorSpeed( m_driverId, m_motorSpeed );
			b2Joint_WakeBodies( m_driverId );
		}

		if ( glfwGetKey( m_context->window, GLFW_KEY_D ) )
		{
			m_motorSpeed = b2MinFloat( 0.3f, m_motorSpeed + 0.01f );
			b2RevoluteJoint_SetTargetMotorSpeed( m_driverId, m_motorSpeed );
			b2Joint_WakeBodies( m_driverId );
		}

		Sample::Step();
	}

	static Sample* Create( SampleContext* context )
	{
		return new GearLift( context );
	}

	b2JointId m_driverId;
	float m_motorTorque;
	float m_motorSpeed;
	bool m_enableMotor;
};

static int sampleGearLift = RegisterSample( "Joints", "Gear Lift", GearLift::Create );

// A top down door
class Door : public Sample
{
public:
	explicit Door( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 0.0f };
			m_context->camera.zoom = 4.0f;
		}

		b2BodyId groundId = b2_nullBodyId;
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.position = { 0.0f, 0.0f };
			groundId = b2CreateBody( m_worldId, &bodyDef );
		}

		m_enableLimit = true;
		m_impulse = 50000.0f;
		m_translationError = 0.0f;
		m_jointHertz = 240.0f;
		m_jointDampingRatio = 1.0f;

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { 0.0f, 1.5f };
			bodyDef.gravityScale = 0.0f;

			m_doorId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1000.0f;

			b2Polygon box = b2MakeBox( 0.1f, 1.5f );
			b2CreatePolygonShape( m_doorId, &shapeDef, &box );

			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = groundId;
			jointDef.base.bodyIdB = m_doorId;
			jointDef.base.localFrameA.p = { 0.0f, 0.0f };
			jointDef.base.localFrameB.p = { 0.0f, -1.5f };
			jointDef.base.constraintHertz = m_jointHertz;
			jointDef.base.constraintDampingRatio = m_jointDampingRatio;
			jointDef.targetAngle = 0.0f;
			jointDef.enableSpring = true;
			jointDef.hertz = 1.0f;
			jointDef.dampingRatio = 0.5f;
			jointDef.motorSpeed = 0.0f;
			jointDef.maxMotorTorque = 0.0f;
			jointDef.enableMotor = false;
			jointDef.lowerAngle = -0.5f * B2_PI;
			jointDef.upperAngle = 0.5f * B2_PI;
			jointDef.enableLimit = m_enableLimit;

			m_jointId = b2CreateRevoluteJoint( m_worldId, &jointDef );
		}
	}

	bool DrawControls() override
	{
		if ( ImGui::Button( "impulse" ) )
		{
			b2Pos p = b2Body_GetWorldPoint( m_doorId, { 0.0f, 1.5f } );
			b2Body_ApplyLinearImpulse( m_doorId, { m_impulse, 0.0f }, p, true );
			m_translationError = 0.0f;
		}

		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		ImGui::SliderFloat( "magnitude", &m_impulse, 1000.0f, 100000.0f, "%.0f" );

		if ( ImGui::SliderFloat( "hertz", &m_jointHertz, 15.0f, 480.0f, "%.0f" ) )
		{
			b2Joint_SetConstraintTuning( m_jointId, m_jointHertz, m_jointDampingRatio );
		}

		if ( ImGui::SliderFloat( "damping", &m_jointDampingRatio, 0.0f, 10.0f, "%.1f" ) )
		{
			b2Joint_SetConstraintTuning( m_jointId, m_jointHertz, m_jointDampingRatio );
		}

		ImGui::PopItemWidth();

		if ( ImGui::Checkbox( "limit", &m_enableLimit ) )
		{
			b2RevoluteJoint_EnableLimit( m_jointId, m_enableLimit );
		}

		return true;
	}

	void Step() override
	{
		Sample::Step();

		b2Pos p = b2Body_GetWorldPoint( m_doorId, { 0.0f, 1.5f } );
		DrawPoint( m_draw, p, 5.0f, b2_colorDarkKhaki );

		float translationError = b2Joint_GetLinearSeparation( m_jointId );
		m_translationError = b2MaxFloat( m_translationError, translationError );

		DrawScreenTextLine( "translation error = %g", m_translationError );
	}

	static Sample* Create( SampleContext* context )
	{
		return new Door( context );
	}

	b2BodyId m_doorId;
	b2JointId m_jointId;
	float m_impulse;
	float m_translationError;
	float m_jointHertz;
	float m_jointDampingRatio;
	bool m_enableLimit;
};

static int sampleDoor = RegisterSample( "Joints", "Door", Door::Create );

class ScaleRagdoll : public Sample
{
public:
	explicit ScaleRagdoll( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 4.5f };
			m_context->camera.zoom = 6.0f;
		}

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );
			b2ShapeDef shapeDef = b2DefaultShapeDef();

			b2Polygon box = b2MakeOffsetBox( 20.0f, 1.0f, { 0.0f, -1.0f }, b2Rot_identity );
			b2CreatePolygonShape( groundId, &shapeDef, &box );
		}

		m_scale = 1.0f;

		m_human = {};

		Spawn();
	}

	void Spawn()
	{
		float jointFrictionTorque = 0.03f;
		float jointHertz = 1.0f;
		float jointDampingRatio = 0.5f;
		CreateHuman( &m_human, m_worldId, { 0.0f, 5.0f }, m_scale, jointFrictionTorque, jointHertz, jointDampingRatio, 1, nullptr,
					 false );
		Human_ApplyRandomAngularImpulse( &m_human, 0.1f );
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Scale", &m_scale, 0.1f, 10.0f, "%3.2f", ImGuiSliderFlags_ClampOnInput ) )
		{
			Human_SetScale( &m_human, m_scale );
		}

		ImGui::PopItemWidth();

		return true;
	}

	static Sample* Create( SampleContext* context )
	{
		return new ScaleRagdoll( context );
	}

	Human m_human;
	float m_scale;
};

static int sampleScaleRagdoll = RegisterSample( "Joints", "Scale Ragdoll", ScaleRagdoll::Create );

// Theo Jansen's walking machine, inspired by a contribution from roman_m
// Dimensions scooped from APE (http://www.cove.org/ape/index.htm)
class TheoJansen : public Sample
{
public:
	explicit TheoJansen( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.0f, 6.0f };
			m_context->camera.zoom = 25.0f * 0.5f;
		}

		m_offset = { 0.0f, 8.0f };
		m_motorSpeed = 2.0f;
		m_enableMotor = true;
		b2Vec2 pivot = { 0.0f, 0.8f };

		// Ground
		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();

			b2Segment segment = { { -50.0f, 0.0f }, { 50.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			segment = { { -50.0f, 0.0f }, { -50.0f, 10.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );

			segment = { { 50.0f, 0.0f }, { 50.0f, 10.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		// Balls
		for ( int i = 0; i < 40; ++i )
		{
			b2Circle circle = { { 0.0f, 0.0f }, 0.25f };

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = { -40.0f + 2.0f * i, 0.5f };

			b2BodyId bodyId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1.0f;
			b2CreateCircleShape( bodyId, &shapeDef, &circle );
		}

		// Chassis
		{
			b2Polygon box = b2MakeBox( 2.5f, 1.0f );

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = b2ToPos( pivot ) + m_offset;
			m_chassisId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1.0f;
			shapeDef.filter.groupIndex = -1;
			b2CreatePolygonShape( m_chassisId, &shapeDef, &box );
		}

		// Wheel
		{
			b2Circle circle = { { 0.0f, 0.0f }, 1.6f };

			b2BodyDef bodyDef = b2DefaultBodyDef();
			bodyDef.type = b2_dynamicBody;
			bodyDef.position = b2ToPos( pivot ) + m_offset;
			m_wheelId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			shapeDef.density = 1.0f;
			shapeDef.filter.groupIndex = -1;
			b2CreateCircleShape( m_wheelId, &shapeDef, &circle );
		}

		{
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = m_wheelId;
			jointDef.base.bodyIdB = m_chassisId;

			b2Pos motorPivot = b2ToPos( pivot ) + m_offset;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( jointDef.base.bodyIdA, motorPivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( jointDef.base.bodyIdB, motorPivot );

			jointDef.enableMotor = m_enableMotor;
			jointDef.motorSpeed = m_motorSpeed;
			jointDef.maxMotorTorque = 400.0f;
			m_motorJointId = b2CreateRevoluteJoint( m_worldId, &jointDef );
		}

		b2Vec2 wheelAnchor = pivot + b2Vec2{ 0.0f, -0.8f };

		CreateLeg( -1.0f, wheelAnchor );
		CreateLeg( 1.0f, wheelAnchor );

		// Stagger three leg pairs around the wheel so some feet always touch the ground
		b2Body_SetTransform( m_wheelId, b2Body_GetPosition( m_wheelId ), b2MakeRot( 120.0f * B2_PI / 180.0f ) );
		CreateLeg( -1.0f, wheelAnchor );
		CreateLeg( 1.0f, wheelAnchor );

		b2Body_SetTransform( m_wheelId, b2Body_GetPosition( m_wheelId ), b2MakeRot( -120.0f * B2_PI / 180.0f ) );
		CreateLeg( -1.0f, wheelAnchor );
		CreateLeg( 1.0f, wheelAnchor );
	}

	void CreateLeg( float s, b2Vec2 wheelAnchor )
	{
		b2Vec2 p1 = { 5.4f * s, -6.1f };
		b2Vec2 p2 = { 7.2f * s, -1.2f };
		b2Vec2 p3 = { 4.3f * s, -1.9f };
		b2Vec2 p4 = { 3.1f * s, 0.8f };
		b2Vec2 p5 = { 6.0f * s, 1.5f };
		b2Vec2 p6 = { 2.5f * s, 3.7f };

		// The hull computation handles the mirrored winding for s < 0
		b2Vec2 vertices1[3] = { p1, p2, p3 };
		b2Vec2 vertices2[3] = { b2Vec2_zero, p5 - p4, p6 - p4 };

		b2Hull hull1 = b2ComputeHull( vertices1, 3 );
		b2Hull hull2 = b2ComputeHull( vertices2, 3 );
		b2Polygon poly1 = b2MakePolygon( &hull1, 0.0f );
		b2Polygon poly2 = b2MakePolygon( &hull2, 0.0f );

		b2BodyDef bodyDef1 = b2DefaultBodyDef();
		bodyDef1.type = b2_dynamicBody;
		bodyDef1.position = b2ToPos( m_offset );
		bodyDef1.angularDamping = 10.0f;
		b2BodyId body1 = b2CreateBody( m_worldId, &bodyDef1 );

		b2BodyDef bodyDef2 = b2DefaultBodyDef();
		bodyDef2.type = b2_dynamicBody;
		bodyDef2.position = b2ToPos( p4 ) + m_offset;
		bodyDef2.angularDamping = 10.0f;
		b2BodyId body2 = b2CreateBody( m_worldId, &bodyDef2 );

		// Negative group index keeps the legs from colliding with the chassis and wheel
		b2ShapeDef shapeDef = b2DefaultShapeDef();
		shapeDef.density = 1.0f;
		shapeDef.filter.groupIndex = -1;
		b2CreatePolygonShape( body1, &shapeDef, &poly1 );
		b2CreatePolygonShape( body2, &shapeDef, &poly2 );

		{
			// Soft distance constraints reduce jitter and act like a suspension system
			b2DistanceJointDef jointDef = b2DefaultDistanceJointDef();
			jointDef.enableSpring = true;
			jointDef.hertz = 10.0f;
			jointDef.dampingRatio = 0.5f;

			jointDef.base.bodyIdA = body1;
			jointDef.base.bodyIdB = body2;

			b2Pos anchorA = b2ToPos( p2 ) + m_offset;
			b2Pos anchorB = b2ToPos( p5 ) + m_offset;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( body1, anchorA );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( body2, anchorB );
			jointDef.length = b2Length( anchorA - anchorB );
			b2CreateDistanceJoint( m_worldId, &jointDef );

			anchorA = b2ToPos( p3 ) + m_offset;
			anchorB = b2ToPos( p4 ) + m_offset;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( body1, anchorA );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( body2, anchorB );
			jointDef.length = b2Length( anchorA - anchorB );
			b2CreateDistanceJoint( m_worldId, &jointDef );

			jointDef.base.bodyIdB = m_wheelId;
			anchorB = b2ToPos( wheelAnchor ) + m_offset;
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( m_wheelId, anchorB );
			jointDef.length = b2Length( anchorA - anchorB );
			b2CreateDistanceJoint( m_worldId, &jointDef );

			jointDef.base.bodyIdA = body2;
			anchorA = b2ToPos( p6 ) + m_offset;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( body2, anchorA );
			jointDef.length = b2Length( anchorA - anchorB );
			b2CreateDistanceJoint( m_worldId, &jointDef );
		}

		{
			b2RevoluteJointDef jointDef = b2DefaultRevoluteJointDef();
			jointDef.base.bodyIdA = body2;
			jointDef.base.bodyIdB = m_chassisId;

			b2Pos legPivot = b2ToPos( p4 ) + m_offset;
			jointDef.base.localFrameA.p = b2Body_GetLocalPoint( body2, legPivot );
			jointDef.base.localFrameB.p = b2Body_GetLocalPoint( m_chassisId, legPivot );
			b2CreateRevoluteJoint( m_worldId, &jointDef );
		}
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::Checkbox( "Motor", &m_enableMotor ) )
		{
			b2RevoluteJoint_EnableMotor( m_motorJointId, m_enableMotor );
		}

		if ( ImGui::SliderFloat( "Speed", &m_motorSpeed, -5.0f, 5.0f, "%.1f" ) )
		{
			b2RevoluteJoint_SetTargetMotorSpeed( m_motorJointId, m_motorSpeed );
		}

		ImGui::PopItemWidth();

		return true;
	}

	void Step() override
	{
		DrawScreenTextLine( "Keys: left = a, brake = s, right = d, toggle motor = f" );

		Sample::Step();
	}

	void Keyboard( int key, int, int ) override
	{
		switch ( key )
		{
			case GLFW_KEY_A:
				b2RevoluteJoint_SetTargetMotorSpeed( m_motorJointId, -m_motorSpeed );
				break;

			case GLFW_KEY_S:
				b2RevoluteJoint_SetTargetMotorSpeed( m_motorJointId, 0.0f );
				break;

			case GLFW_KEY_D:
				b2RevoluteJoint_SetTargetMotorSpeed( m_motorJointId, m_motorSpeed );
				break;

			case GLFW_KEY_F:
				m_enableMotor = !b2RevoluteJoint_IsMotorEnabled( m_motorJointId );
				b2RevoluteJoint_EnableMotor( m_motorJointId, m_enableMotor );
				break;

			default:
				break;
		}
	}

	static Sample* Create( SampleContext* context )
	{
		return new TheoJansen( context );
	}

	b2Vec2 m_offset;
	b2BodyId m_chassisId;
	b2BodyId m_wheelId;
	b2JointId m_motorJointId;
	float m_motorSpeed;
	bool m_enableMotor;
};

static int sampleTheoJansen = RegisterSample( "Joints", "Theo Jansen", TheoJansen::Create );

// The Anglepoise Original 1227 desk lamp.
// https://www.anglepoise.com/usa/product-category/original-1227/
class DeskLamp : public Sample
{
public:
	enum
	{
		e_springCount = 2
	};

	explicit DeskLamp( SampleContext* context )
		: Sample( context )
	{
		if ( m_context->restart == false )
		{
			m_context->camera.center = { 0.2f, 1.42f };
			m_context->camera.zoom = 1.6f;
		}

		// The parallelogram is narrow, so it wants the extra resolution
		m_context->subStepCount = 8;

		{
			b2BodyDef bodyDef = b2DefaultBodyDef();
			b2BodyId groundId = b2CreateBody( m_worldId, &bodyDef );

			b2ShapeDef shapeDef = b2DefaultShapeDef();
			b2Segment segment = { { -20.0f, 0.0f }, { 20.0f, 0.0f } };
			b2CreateSegmentShape( groundId, &shapeDef, &segment );
		}

		// Dimensions taken off an Original 1227 in meters, then scaled up. At life size the silver
		// link is two centimeters, which is far too close to the linear slop.
		float scale = 5.0f;

		float baseHalfWidth = 0.070f * scale;
		float baseHalfHeight = 0.018f * scale;
		float postHalfWidth = 0.008f * scale;
		float pivotHeight = 0.185f * scale;
		float springAnchorHeight = 0.095f * scale;
		float topLinkLength = 0.296f * scale;
		float silverFoot = 0.024f * scale;
		float topLeverLength = 0.019f * scale;
		float lowerLeverLength = 0.028f * scale;
		float upperArmLength = 0.324f * scale;
		float tubeRadius = 0.0036f * scale;
		float shadeLength = 0.161f * scale;
		float shadeNeckRadius = 0.020f * scale;
		float shadeMouthRadius = 0.061f * scale;

		// The silver link measured in the top link frame. The same span separates the two pins on the
		// upper arm, which is what closes the parallelogram.
		b2Vec2 silverSpan = { 0.0212f * scale, 0.0109f * scale };
		float silverLength = b2Length( silverSpan );

		float topLinkAngle = -0.878f;
		float upperArmAngle = 1.192f;
		float shadeTilt = -0.41f;

		// The arm spring balances the elevation, the head spring balances the upper arm through the
		// parallelogram. That is what the real lamp uses two springs for.
		m_springHertz[0] = 5.0f;
		m_springHertz[1] = 5.0f;
		m_springDamping = 4.0f;
		m_lowerFriction = 100.0f;
		m_elbowFriction = 100.0f;
		m_headAngle = 0.0f;
		b2Rot topRotation = b2MakeRot( topLinkAngle );
		b2Rot upperRotation = b2MakeRot( upperArmAngle );

		b2Vec2 topAxis = b2Rot_GetYAxis( topRotation );
		b2Vec2 silverWorld = b2RotateVector( topRotation, silverSpan );

		b2Pos postPivot = { 0.0f, pivotHeight };
		b2Pos upperPin = b2OffsetPos( postPivot, b2MulSV( topLinkLength, topAxis ) );
		b2Pos silverBase = b2OffsetPos( postPivot, b2MulSV( silverFoot, topAxis ) );
		b2Pos lowerFoot = b2OffsetPos( silverBase, silverWorld );
		b2Pos lowerPin = b2OffsetPos( upperPin, silverWorld );

		// The lower link is parallel to the top link and shorter by the silver link foot
		float lowerLinkLength = topLinkLength - silverFoot;
		b2Rot silverRotation = b2MakeRotFromUnitVector( b2RightPerp( b2Normalize( silverWorld ) ) );

		b2Pos headPivot = b2OffsetPos( upperPin, b2MulSV( upperArmLength, b2Rot_GetYAxis( upperRotation ) ) );

		b2BodyDef bodyDef = b2DefaultBodyDef();
		bodyDef.type = b2_dynamicBody;

		b2ShapeDef shapeDef = b2DefaultShapeDef();

		b2BodyId baseId;
		{
			// The base is static so the linkage is all that moves
			bodyDef.type = b2_staticBody;
			bodyDef.position = b2Pos_zero;
			bodyDef.rotation = b2Rot_identity;
			baseId = b2CreateBody( m_worldId, &bodyDef );

			b2Polygon plinth = b2MakeOffsetBox( baseHalfWidth, baseHalfHeight, { 0.0f, baseHalfHeight }, b2Rot_identity );
			float postHalfHeight = 0.5f * ( pivotHeight - 2.0f * baseHalfHeight );
			b2Polygon post =
				b2MakeOffsetBox( postHalfWidth, postHalfHeight, { 0.0f, pivotHeight - postHalfHeight }, b2Rot_identity );

			b2CreatePolygonShape( baseId, &shapeDef, &plinth );
			b2CreatePolygonShape( baseId, &shapeDef, &post );
		}

		bodyDef.type = b2_dynamicBody;
		shapeDef.density = 20.0f;

		// Both long links run past their feet into the levers the springs pull on
		{
			bodyDef.position = postPivot;
			bodyDef.rotation = topRotation;
			m_topLinkId = b2CreateBody( m_worldId, &bodyDef );

			b2Capsule capsule = { { 0.0f, -topLeverLength }, { 0.0f, topLinkLength }, tubeRadius };
			b2CreateCapsuleShape( m_topLinkId, &shapeDef, &capsule );
		}

		b2BodyId lowerLinkId;
		{
			bodyDef.position = lowerFoot;
			bodyDef.rotation = topRotation;
			lowerLinkId = b2CreateBody( m_worldId, &bodyDef );

			b2Capsule capsule = { { 0.0f, -lowerLeverLength }, { 0.0f, lowerLinkLength }, tubeRadius };
			b2CreateCapsuleShape( lowerLinkId, &shapeDef, &capsule );
		}

		b2BodyId silverId;
		{
			bodyDef.position = silverBase;
			bodyDef.rotation = silverRotation;
			silverId = b2CreateBody( m_worldId, &bodyDef );

			b2Capsule capsule = { { 0.0f, 0.0f }, { 0.0f, silverLength }, 1.4f * tubeRadius };
			shapeDef.material.customColor = b2_colorSilver;
			b2CreateCapsuleShape( silverId, &shapeDef, &capsule );
			shapeDef.material.customColor = 0;
		}

		b2BodyId upperArmId;
		{
			bodyDef.position = upperPin;
			bodyDef.rotation = upperRotation;
			upperArmId = b2CreateBody( m_worldId, &bodyDef );

			b2Capsule capsule = { { 0.0f, 0.0f }, { 0.0f, upperArmLength }, 0.8f * tubeRadius };
			b2CreateCapsuleShape( upperArmId, &shapeDef, &capsule );

			// The coupler span reaches back to the lower link pin
			b2Capsule bracket = { { 0.0f, 0.0f }, b2Body_GetLocalPoint( upperArmId, lowerPin ), tubeRadius };
			b2CreateCapsuleShape( upperArmId, &shapeDef, &bracket );
		}

		b2RevoluteJointDef pinDef = b2DefaultRevoluteJointDef();
		pinDef.base.drawScale = 0.03f * scale;
		pinDef.base.constraintHertz = 240.0f;
		pinDef.base.constraintDampingRatio = 2.0f;

		// Only the top link reaches the post. The springs carry it, so it needs little friction.
		pinDef.base.bodyIdA = baseId;
		pinDef.base.bodyIdB = m_topLinkId;
		pinDef.base.localFrameA.p = b2Body_GetLocalPoint( baseId, postPivot );
		pinDef.base.localFrameB.p = b2Vec2_zero;
		pinDef.enableMotor = true;
		pinDef.maxMotorTorque = m_lowerFriction;
		m_postJointId = b2CreateRevoluteJoint( m_worldId, &pinDef );

		pinDef.enableMotor = false;

		// The silver link hangs off the top link and carries the foot of the lower link
		pinDef.base.bodyIdA = m_topLinkId;
		pinDef.base.bodyIdB = silverId;
		pinDef.base.localFrameA.p = { 0.0f, silverFoot };
		pinDef.base.localFrameB.p = b2Vec2_zero;
		b2CreateRevoluteJoint( m_worldId, &pinDef );

		pinDef.base.bodyIdA = silverId;
		pinDef.base.bodyIdB = lowerLinkId;
		pinDef.base.localFrameA.p = { 0.0f, silverLength };
		pinDef.base.localFrameB.p = b2Vec2_zero;
		b2CreateRevoluteJoint( m_worldId, &pinDef );

		// Both long links reach the upper arm, at points a silver link apart.
		pinDef.base.bodyIdA = lowerLinkId;
		pinDef.base.bodyIdB = upperArmId;
		pinDef.base.localFrameA.p = { 0.0f, lowerLinkLength };
		pinDef.base.localFrameB.p = b2Body_GetLocalPoint( upperArmId, lowerPin );
		b2CreateRevoluteJoint( m_worldId, &pinDef );

		// No spring reaches the elbow, so it is a friction pivot like the real one.
		pinDef.base.bodyIdA = m_topLinkId;
		pinDef.base.bodyIdB = upperArmId;
		pinDef.base.localFrameA.p = { 0.0f, topLinkLength };
		pinDef.base.localFrameB.p = b2Vec2_zero;
		pinDef.enableMotor = true;
		pinDef.maxMotorTorque = m_elbowFriction;
		m_elbowJointId = b2CreateRevoluteJoint( m_worldId, &pinDef );

		b2DistanceJointDef springDef = b2DefaultDistanceJointDef();
		springDef.base.drawScale = 0.03f * scale;
		springDef.enableSpring = true;
		springDef.dampingRatio = m_springDamping;

		// A coil spring only pulls
		//springDef.upperSpringForce = 0.0f;

		// Carwardine's trick. With almost no free length the spring torque about the pivot is
		// k times cross(lever, anchor), which tracks the gravity torque as the arm swings, so the
		// arm balances over its whole range instead of at one angle.
		springDef.length = 0.01f;

		b2Pos springBase = { 0.0f, springAnchorHeight };
		b2BodyId leverIds[e_springCount] = { m_topLinkId, lowerLinkId };
		float leverLengths[e_springCount] = { topLeverLength, lowerLeverLength };

		for ( int k = 0; k < e_springCount; ++k )
		{
			springDef.base.bodyIdA = baseId;
			springDef.base.bodyIdB = leverIds[k];
			springDef.base.localFrameA.p = b2Body_GetLocalPoint( baseId, springBase );
			springDef.base.localFrameB.p = { 0.0f, -leverLengths[k] };
			springDef.hertz = m_springHertz[k];
			m_springJointIds[k] = b2CreateDistanceJoint( m_worldId, &springDef );
		}

		{
			bodyDef.position = headPivot;
			bodyDef.rotation = b2MakeRot( shadeTilt );
			b2BodyId headId = b2CreateBody( m_worldId, &bodyDef );

			// The pivot is on the shade center line, where the arm capsule ends. The shade opens along
			// the local negative y.
			float neck = 0.45f * shadeLength;
			float mouth = neck - shadeLength;
			b2Vec2 points[4] = { { -shadeNeckRadius, neck },
								 { shadeNeckRadius, neck },
								 { shadeMouthRadius, mouth },
								 { -shadeMouthRadius, mouth } };
			b2Hull hull = b2ComputeHull( points, 4 );
			b2Polygon shade = b2MakePolygon( &hull, 0.01f * scale );

			// The shade is a thin shell.
			shapeDef.density = 1.0f;
			b2CreatePolygonShape( headId, &shapeDef, &shade );

			// Offset the reference frame so the head slider reads zero at the pose above.
			pinDef.base.bodyIdA = upperArmId;
			pinDef.base.bodyIdB = headId;
			pinDef.base.localFrameA.p = { 0.0f, upperArmLength };
			pinDef.base.localFrameA.q = b2InvMulRot( upperRotation, b2MakeRot( shadeTilt ) );
			pinDef.base.localFrameB.p = b2Vec2_zero;
			pinDef.enableMotor = false;
			pinDef.maxMotorTorque = 10.0f;
			pinDef.enableSpring = true;
			pinDef.hertz = 8.0f;
			pinDef.dampingRatio = 2.0f;
			pinDef.targetAngle = m_headAngle;
			pinDef.enableLimit = true;
			pinDef.lowerAngle = -1.2f;
			pinDef.upperAngle = 1.2f;
			m_headJointId = b2CreateRevoluteJoint( m_worldId, &pinDef );
		}
	}

	bool DrawControls() override
	{
		ImGui::PushItemWidth( 6.0f * ImGui::GetFontSize() );

		if ( ImGui::SliderFloat( "Arm Spring", &m_springHertz[0], 0.0f, 20.0f, "%.2f" ) )
		{
			b2DistanceJoint_SetSpringHertz( m_springJointIds[0], m_springHertz[0] );
			b2Joint_WakeBodies( m_springJointIds[0] );
		}

		if ( ImGui::SliderFloat( "Head Spring", &m_springHertz[1], 0.0f, 20.0f, "%.2f" ) )
		{
			b2DistanceJoint_SetSpringHertz( m_springJointIds[1], m_springHertz[1] );
			b2Joint_WakeBodies( m_springJointIds[1] );
		}

		if ( ImGui::SliderFloat( "Spring Damping", &m_springDamping, 0.0f, 5.0f, "%.1f" ) )
		{
			for ( int k = 0; k < e_springCount; ++k )
			{
				b2DistanceJoint_SetSpringDampingRatio( m_springJointIds[k], m_springDamping );
				b2Joint_WakeBodies( m_springJointIds[k] );
			}
		}

		if ( ImGui::SliderFloat( "Post Friction", &m_lowerFriction, 0.0f, 20.0f, "%.1f" ) )
		{
			b2RevoluteJoint_SetMaxMotorTorque( m_postJointId, m_lowerFriction );
			b2Joint_WakeBodies( m_postJointId );
		}

		if ( ImGui::SliderFloat( "Elbow Friction", &m_elbowFriction, 0.0f, 60.0f, "%.0f" ) )
		{
			b2RevoluteJoint_SetMaxMotorTorque( m_elbowJointId, m_elbowFriction );
			b2Joint_WakeBodies( m_elbowJointId );
		}

		if ( ImGui::SliderFloat( "Head", &m_headAngle, -1.2f, 1.2f, "%.2f" ) )
		{
			b2RevoluteJoint_SetTargetAngle( m_headJointId, m_headAngle );
			b2Joint_WakeBodies( m_headJointId );
		}

		ImGui::PopItemWidth();

		return true;
	}

	void Step() override
	{
		Sample::Step();

		float postTorque = b2RevoluteJoint_GetCurrentMotorTorque( m_postJointId );
		float elbowTorque = b2RevoluteJoint_GetCurrentMotorTorque( m_elbowJointId );
		DrawScreenTextLine( "friction carrying: post %.2f, elbow %.2f N m", postTorque, elbowTorque );

		float spring1 = b2DistanceJoint_GetSpringForce( m_springJointIds[0] );
		float spring2 = b2DistanceJoint_GetSpringForce( m_springJointIds[1] );
		DrawScreenTextLine( "spring forces: %.2f, %.2f N", spring1, spring2 );
	}

	static Sample* Create( SampleContext* context )
	{
		return new DeskLamp( context );
	}

	b2JointId m_springJointIds[e_springCount];
	b2JointId m_postJointId;
	b2JointId m_elbowJointId;
	b2JointId m_headJointId;
	b2BodyId m_topLinkId;
	float m_springHertz[e_springCount];
	float m_springDamping;
	float m_lowerFriction;
	float m_elbowFriction;
	float m_headAngle;
};

static int sampleDeskLamp = RegisterSample( "Joints", "Desk Lamp", DeskLamp::Create );
