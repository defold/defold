# Samples {#samples_app}

Once you have conquered the [HelloWorld](@ref hello) example, you should start looking at Box2D's
samples application. The samples application is a testing framework and demo environment. Here are
some of the features:

- Camera with pan and zoom.
- Mouse dragging of dynamic bodies.
- GUI for selecting samples, parameter tuning, and debug drawing options.
- Pause and single step simulation.
- Multithreading and performance data.
- Replay viewer for debugging recordings from your game.

[![Box2D Samples](images/samples.png)](samples.png)

The samples application has many examples of Box2D usage in the test cases and the framework itself.
I encourage you to explore and tinker with the samples as you learn Box2D.

> [!note]
> The samples application is written using [GLFW](https://www.glfw.org) and
> [imgui](https://github.com/ocornut/imgui). The samples app is not part of the Box2D library. The
> Box2D library is agnostic about rendering. As shown by the HelloWorld example, you don't need a
> renderer to use Box2D.
